import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import api from "../services/api";
import AdminLayout from "../components/AdminLayout";

// =====================================================
// API SERVER URL
// =====================================================
const API_SERVER_URL = (
  import.meta.env.VITE_API_URL || "http://localhost:5000/api"
).replace(/\/api\/?$/, "");

// =====================================================
// IMAGE URL HELPER
// =====================================================
const getImageUrl = (image) => {
  if (!image) return "";

  if (image.startsWith("http")) {
    return image;
  }

  return `${API_SERVER_URL}${image.startsWith("/") ? image : `/${image}`}`;
};

// =====================================================
// COURSES COMPONENT
// =====================================================
const Courses = () => {
  const navigate = useNavigate();

  // ===================================================
  // STATE
  // ===================================================
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const [searchTerm, setSearchTerm] = useState("");

  // Edit Modal
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [editLoading, setEditLoading] = useState(false);

  // Delete
  const [deleteLoading, setDeleteLoading] = useState(null);

  // Edit Form
  const [editFormData, setEditFormData] = useState({
    courseName: "",
    courseDuration: "",
    courseSession: "",
    courseDescription: "",
    courseImage: null,
  });

  const [editImagePreview, setEditImagePreview] = useState(null);

  // ===================================================
  // GET COURSES
  // ===================================================
  const fetchCourses = async () => {
    try {
      setLoading(true);
      setErrorMessage("");

      const response = await api.get("/courses");

      if (response.data?.success) {
        setCourses(
          Array.isArray(response.data.courses)
            ? response.data.courses
            : []
        );
      } else {
        setCourses([]);
        setErrorMessage(
          response.data?.message || "Failed to load courses."
        );
      }
    } catch (error) {
      console.error("Get Courses Error:", error);

      setErrorMessage(
        error.response?.data?.message ||
          "Failed to load courses. Please check your server."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, []);

  // ===================================================
  // SEARCH
  // ===================================================
  const filteredCourses = courses.filter((course) => {
    const search = searchTerm.toLowerCase().trim();

    if (!search) return true;

    return (
      course.courseName?.toLowerCase().includes(search) ||
      course.courseDuration?.toLowerCase().includes(search) ||
      course.courseSession?.toLowerCase().includes(search) ||
      course.courseDescription?.toLowerCase().includes(search)
    );
  });

  // ===================================================
  // EDIT INPUT CHANGE
  // ===================================================
  const handleEditChange = (e) => {
    const { name, value } = e.target;

    setEditFormData((previous) => ({
      ...previous,
      [name]: value,
    }));

    setErrorMessage("");
  };

  // ===================================================
  // EDIT IMAGE CHANGE
  // ===================================================
  const handleEditImageChange = (e) => {
    const file = e.target.files?.[0];

    if (!file) return;

    const allowedTypes = [
      "image/jpeg",
      "image/jpg",
      "image/png",
      "image/webp",
    ];

    if (!allowedTypes.includes(file.type)) {
      setErrorMessage(
        "Only JPG, JPEG, PNG and WEBP images are allowed."
      );

      e.target.value = "";
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setErrorMessage("Image size must be less than 5MB.");

      e.target.value = "";
      return;
    }

    setErrorMessage("");

    if (
      editImagePreview &&
      editImagePreview.startsWith("blob:")
    ) {
      URL.revokeObjectURL(editImagePreview);
    }

    const preview = URL.createObjectURL(file);

    setEditFormData((previous) => ({
      ...previous,
      courseImage: file,
    }));

    setEditImagePreview(preview);
  };

  // ===================================================
  // OPEN EDIT MODAL
  // ===================================================
  const handleEdit = (course) => {
    setSelectedCourse(course);

    setEditFormData({
      courseName: course.courseName || "",
      courseDuration: course.courseDuration || "",
      courseSession: course.courseSession || "",
      courseDescription: course.courseDescription || "",
      courseImage: null,
    });

    setEditImagePreview(
      course.courseImage
        ? getImageUrl(course.courseImage)
        : null
    );

    setShowEditModal(true);
    setErrorMessage("");
    setSuccessMessage("");
  };

  // ===================================================
  // CLOSE EDIT MODAL
  // ===================================================
  const handleCloseEdit = () => {
    if (
      editImagePreview &&
      editImagePreview.startsWith("blob:")
    ) {
      URL.revokeObjectURL(editImagePreview);
    }

    setShowEditModal(false);
    setSelectedCourse(null);

    setEditFormData({
      courseName: "",
      courseDuration: "",
      courseSession: "",
      courseDescription: "",
      courseImage: null,
    });

    setEditImagePreview(null);
    setErrorMessage("");
  };

  // ===================================================
  // UPDATE COURSE
  // ===================================================
  const handleUpdate = async (e) => {
    e.preventDefault();

    if (!selectedCourse) return;

    if (!editFormData.courseName.trim()) {
      setErrorMessage("Course name is required.");
      return;
    }

    if (!editFormData.courseDuration.trim()) {
      setErrorMessage("Course duration is required.");
      return;
    }

    if (!editFormData.courseSession.trim()) {
      setErrorMessage("Course session is required.");
      return;
    }

    try {
      setEditLoading(true);
      setErrorMessage("");
      setSuccessMessage("");

      const data = new FormData();

      data.append(
        "courseName",
        editFormData.courseName.trim()
      );

      data.append(
        "courseDuration",
        editFormData.courseDuration.trim()
      );

      data.append(
        "courseSession",
        editFormData.courseSession.trim()
      );

      data.append(
        "courseDescription",
        editFormData.courseDescription.trim()
      );

      if (editFormData.courseImage) {
        data.append(
          "courseImage",
          editFormData.courseImage
        );
      }

      const response = await api.put(
        `/courses/${selectedCourse.id}`,
        data
      );

      if (response.data?.success) {
        handleCloseEdit();

        setSuccessMessage(
          response.data?.message ||
            "Course updated successfully!"
        );

        await fetchCourses();

        setTimeout(() => {
          setSuccessMessage("");
        }, 3000);
      } else {
        setErrorMessage(
          response.data?.message ||
            "Failed to update course."
        );
      }
    } catch (error) {
      console.error("Update Course Error:", error);

      setErrorMessage(
        error.response?.data?.message ||
          "Failed to update course."
      );
    } finally {
      setEditLoading(false);
    }
  };

  // ===================================================
  // DELETE COURSE
  // ===================================================
  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this course?"
    );

    if (!confirmDelete) return;

    try {
      setDeleteLoading(id);
      setErrorMessage("");
      setSuccessMessage("");

      const response = await api.delete(`/courses/${id}`);

      if (response.data?.success) {
        setCourses((previous) =>
          previous.filter((course) => course.id !== id)
        );

        setSuccessMessage(
          response.data?.message ||
            "Course deleted successfully!"
        );

        setTimeout(() => {
          setSuccessMessage("");
        }, 3000);
      } else {
        setErrorMessage(
          response.data?.message ||
            "Failed to delete course."
        );
      }
    } catch (error) {
      console.error("Delete Course Error:", error);

      setErrorMessage(
        error.response?.data?.message ||
          "Failed to delete course."
      );
    } finally {
      setDeleteLoading(null);
    }
  };

  // ===================================================
  // LOADING SCREEN
  // ===================================================
  if (loading) {
    return (
      <AdminLayout title="Courses">
        <div className="flex min-h-[70vh] items-center justify-center bg-[#F5F7F4]">
          <div className="text-center">
            <div className="mx-auto h-14 w-14 animate-spin rounded-full border-4 border-[#0F5132] border-t-transparent" />

            <p className="mt-4 font-medium text-gray-500">
              Loading courses...
            </p>
          </div>
        </div>
      </AdminLayout>
    );
  }

  // ===================================================
  // MAIN UI
  // ===================================================
  return (
    <AdminLayout title="Courses">
      <div className="min-h-screen bg-[#F5F7F4] p-3 md:p-6">
        <div className="mx-auto max-w-[1500px]">

          {/* ================= PAGE HEADER ================= */}
          <div className="mb-6 flex flex-col gap-5 rounded-[24px] bg-white p-6 shadow-sm lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-center gap-4">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#0F5132] text-2xl shadow-lg shadow-green-900/10">
                📚
              </div>

              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-[#198754]">
                  Academic Management
                </p>

                <h1 className="mt-1 text-2xl font-bold text-gray-900 md:text-3xl">
                  Course Management
                </h1>

                <p className="mt-1 text-sm text-gray-400">
                  Add, edit and manage all courses in one place.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => navigate("/courses/add")}
              className="rounded-2xl bg-[#0F5132] px-6 py-3.5 font-semibold text-white shadow-lg shadow-green-900/10 transition hover:bg-[#198754]"
            >
              + Add New Course
            </button>
          </div>

          {/* ================= SUCCESS ================= */}
          {successMessage && (
            <div className="mb-6 flex items-center gap-3 rounded-2xl border border-green-200 bg-[#F1FAF3] px-5 py-4 text-green-700 shadow-sm">
              <span className="text-xl">✓</span>
              <span className="font-semibold">
                {successMessage}
              </span>
            </div>
          )}

          {/* ================= ERROR ================= */}
          {errorMessage && (
            <div className="mb-6 flex items-center gap-3 rounded-2xl border border-red-200 bg-red-50 px-5 py-4 text-red-700 shadow-sm">
              <span className="text-xl">⚠</span>
              <span className="font-semibold">
                {errorMessage}
              </span>
            </div>
          )}

          {/* ================= STATISTICS ================= */}
          <div className="mb-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                title: "Total Courses",
                count: courses.length,
                subtitle: "Courses available",
                icon: "📚",
                accent: true,
              },
              {
                title: "Search Results",
                count: filteredCourses.length,
                subtitle: "Matching courses",
                icon: "🔎",
                accent: false,
              },
              {
                title: "Course Library",
                count: courses.length,
                subtitle: "Active records",
                icon: "🎓",
                accent: false,
              },
            ].map((item) => (
              <div
                key={item.title}
                className={`rounded-[22px] p-6 shadow-sm ${
                  item.accent
                    ? "bg-gradient-to-br from-[#0F5132] to-[#198754] text-white"
                    : "bg-white text-gray-900"
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p
                      className={
                        item.accent
                          ? "text-sm text-green-100"
                          : "text-sm text-gray-400"
                      }
                    >
                      {item.title}
                    </p>

                    <h3 className="mt-2 text-4xl font-bold">
                      {item.count}
                    </h3>

                    <p
                      className={`mt-2 text-xs ${
                        item.accent
                          ? "text-green-100"
                          : "text-gray-400"
                      }`}
                    >
                      {item.subtitle}
                    </p>
                  </div>

                  <div
                    className={`flex h-12 w-12 items-center justify-center rounded-full text-2xl ${
                      item.accent
                        ? "bg-white/15"
                        : "bg-[#EAF5EE]"
                    }`}
                  >
                    {item.icon}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* ================= SEARCH SECTION ================= */}
          <div className="mb-6 rounded-[24px] bg-white p-6 shadow-sm">
            <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
              <div>
                <h2 className="text-xl font-bold text-gray-900">
                  Course List
                </h2>

                <p className="mt-1 text-sm text-gray-400">
                  View and manage all registered courses.
                </p>
              </div>

              <div className="relative w-full md:w-[420px]">
                <span className="absolute left-4 top-1/2 -translate-y-1/2">
                  🔎
                </span>

                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) =>
                    setSearchTerm(e.target.value)
                  }
                  placeholder="Search courses..."
                  className="w-full rounded-xl border border-gray-200 bg-[#FAFBFA] py-3.5 pl-12 pr-4 text-sm outline-none transition focus:border-[#198754] focus:bg-white focus:ring-4 focus:ring-green-100"
                />
              </div>
            </div>
          </div>

          {/* ================= COURSE TABLE ================= */}
          <div className="overflow-hidden rounded-[26px] bg-white shadow-sm">
            <div className="flex flex-col gap-4 border-b border-gray-100 px-6 py-6 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#EAF5EE] text-xl">
                    🎓
                  </div>

                  <div>
                    <h2 className="text-xl font-bold text-gray-900">
                      All Courses
                    </h2>

                    <p className="mt-1 text-sm text-gray-400">
                      Total Courses:{" "}
                      <span className="font-bold text-[#198754]">
                        {filteredCourses.length}
                      </span>
                    </p>
                  </div>
                </div>
              </div>

              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm("")}
                  className="rounded-xl bg-red-50 px-4 py-2.5 text-sm font-semibold text-red-600 transition hover:bg-red-100"
                >
                  Clear Search
                </button>
              )}
            </div>

            {filteredCourses.length === 0 ? (
              <div className="p-12 text-center">
                <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-[#EAF5EE] text-4xl">
                  📚
                </div>

                <h3 className="mt-5 text-xl font-bold text-gray-900">
                  {courses.length === 0
                    ? "No Courses Found"
                    : "No Matching Courses"}
                </h3>

                <p className="mt-2 text-gray-400">
                  {courses.length === 0
                    ? "Start by adding your first course."
                    : "Try searching with a different course name."}
                </p>

                {courses.length === 0 && (
                  <button
                    type="button"
                    onClick={() => navigate("/courses/add")}
                    className="mt-6 rounded-xl bg-[#0F5132] px-6 py-3.5 font-semibold text-white transition hover:bg-[#198754]"
                  >
                    + Add Course
                  </button>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[1250px]">
                  <thead className="border-b border-gray-100 bg-[#F7F9F7]">
                    <tr>
                      <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-400">
                        #
                      </th>

                      <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-400">
                        Course
                      </th>

                      <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-400">
                        Duration
                      </th>

                      <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-400">
                        Course Session
                      </th>

                      <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-400">
                        Description
                      </th>

                      <th className="px-6 py-4 text-center text-xs font-bold uppercase tracking-wider text-gray-400">
                        Actions
                      </th>
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-gray-100">
                    {filteredCourses.map((course, index) => (
                      <tr
                        key={course.id}
                        className="transition hover:bg-[#F5FAF6]"
                      >
                        <td className="px-6 py-5">
                          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#EAF5EE] text-sm font-bold text-[#198754]">
                            {index + 1}
                          </span>
                        </td>

                        <td className="px-6 py-5">
                          <div className="flex items-center gap-4">
                            {course.courseImage ? (
                              <img
                                src={getImageUrl(
                                  course.courseImage
                                )}
                                alt={
                                  course.courseName || "Course"
                                }
                                className="h-16 w-16 rounded-2xl border border-gray-100 object-cover shadow-sm"
                                onError={(e) => {
                                  e.currentTarget.style.display =
                                    "none";
                                }}
                              />
                            ) : (
                              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#EAF5EE] text-2xl">
                                📚
                              </div>
                            )}

                            <div>
                              <p className="font-bold text-gray-900">
                                {course.courseName}
                              </p>

                              <p className="mt-1 text-xs text-gray-400">
                                Course ID: {course.id}
                              </p>
                            </div>
                          </div>
                        </td>

                        <td className="px-6 py-5">
                          <span className="inline-flex items-center gap-2 rounded-xl bg-[#EAF5EE] px-3 py-2 text-sm font-semibold text-[#198754]">
                            ⏱ {course.courseDuration || "Not specified"}
                          </span>
                        </td>

                        <td className="px-6 py-5">
                          <span className="inline-flex whitespace-nowrap items-center rounded-xl bg-green-50 px-3 py-2 text-sm font-semibold text-[#39704D]">
                            🎓 {course.courseSession || "Not specified"}
                          </span>
                        </td>

                        <td className="max-w-[400px] px-6 py-5">
                          <p className="line-clamp-2 text-sm leading-6 text-gray-500">
                            {course.courseDescription ||
                              "No description available"}
                          </p>
                        </td>

                        <td className="px-6 py-5">
                          <div className="flex items-center justify-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleEdit(course)}
                              className="rounded-xl bg-[#EAF5EE] px-4 py-2.5 text-sm font-semibold text-[#0F5132] transition hover:bg-[#DDF0E3]"
                            >
                              ✏️ Edit
                            </button>

                            <button
                              type="button"
                              onClick={() =>
                                handleDelete(course.id)
                              }
                              disabled={
                                deleteLoading === course.id
                              }
                              className="rounded-xl bg-red-50 px-4 py-2.5 text-sm font-semibold text-red-700 transition hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-50"
                            >
                              {deleteLoading === course.id
                                ? "Deleting..."
                                : "🗑️ Delete"}
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* ================= BOTTOM NOTE ================= */}
          <div className="mt-5 flex items-center gap-3 rounded-2xl border border-[#DDEFE2] bg-[#F3FAF5] p-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#DCEFE2]">
              💡
            </div>

            <p className="text-xs leading-5 text-[#39704D]">
              <strong>Note:</strong> You can add, edit and delete
              courses from this page. Course images should be JPG,
              JPEG, PNG or WEBP and maximum 5MB.
            </p>
          </div>
        </div>
      </div>

      {/* ================= EDIT COURSE MODAL ================= */}
      {showEditModal && selectedCourse && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="max-h-[95vh] w-full max-w-3xl overflow-y-auto rounded-[28px] bg-white shadow-2xl">

            {/* MODAL HEADER */}
            <div className="sticky top-0 z-10 flex items-center justify-between bg-[#0F5132] px-6 py-6 text-white">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-green-200">
                  Course Management
                </p>

                <h2 className="mt-1 text-xl font-bold md:text-2xl">
                  Edit Course
                </h2>

                <p className="mt-1 text-sm text-green-100">
                  Update course information
                </p>
              </div>

              <button
                type="button"
                onClick={handleCloseEdit}
                disabled={editLoading}
                className="flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-2xl transition hover:bg-white/20 disabled:opacity-50"
              >
                ×
              </button>
            </div>

            {/* MODAL FORM */}
            <form
              onSubmit={handleUpdate}
              className="p-6 md:p-8"
            >
              {/* IMAGE */}
              <div className="mb-8">
                <div className="mb-4 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#0F5132] text-sm font-bold text-white">
                    01
                  </div>

                  <div>
                    <h3 className="font-bold text-gray-900">
                      Course Image
                    </h3>

                    <p className="text-xs text-gray-400">
                      Update the course profile image
                    </p>
                  </div>
                </div>

                <div className="flex flex-col gap-5 rounded-2xl bg-[#F7F9F7] p-5 sm:flex-row sm:items-center">
                  <div className="flex h-32 w-full items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed border-[#B7D4C1] bg-white sm:w-40">
                    {editImagePreview ? (
                      <img
                        src={editImagePreview}
                        alt="Course Preview"
                        className="h-full w-full object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = "none";
                        }}
                      />
                    ) : (
                      <div className="text-center">
                        <div className="text-4xl">📚</div>

                        <p className="mt-2 text-xs text-gray-400">
                          No Image
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="w-full flex-1">
                    <label className="mb-2 block text-sm font-semibold text-gray-700">
                      Upload New Image
                    </label>

                    <input
                      type="file"
                      accept="image/jpeg,image/jpg,image/png,image/webp"
                      onChange={handleEditImageChange}
                      className="w-full cursor-pointer rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-[#198754] focus:ring-4 focus:ring-green-100"
                    />

                    <p className="mt-2 text-xs text-gray-400">
                      JPG, JPEG, PNG or WEBP — Maximum 5MB
                    </p>
                  </div>
                </div>
              </div>

              {/* COURSE DETAILS */}
              <div>
                <div className="mb-5 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#0F5132] text-sm font-bold text-white">
                    02
                  </div>

                  <div>
                    <h3 className="font-bold text-gray-900">
                      Course Details
                    </h3>

                    <p className="text-xs text-gray-400">
                      Update basic course information
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                  {/* COURSE NAME */}
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-gray-700">
                      Course Name
                      <span className="ml-1 text-red-500">*</span>
                    </label>

                    <input
                      type="text"
                      name="courseName"
                      value={editFormData.courseName}
                      onChange={handleEditChange}
                      required
                      placeholder="Enter course name"
                      className="w-full rounded-xl border border-gray-200 bg-[#FAFBFA] px-4 py-3.5 text-sm outline-none transition focus:border-[#198754] focus:bg-white focus:ring-4 focus:ring-green-100"
                    />
                  </div>

                  {/* COURSE DURATION */}
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-gray-700">
                      Course Duration
                      <span className="ml-1 text-red-500">*</span>
                    </label>

                    <input
                      type="text"
                      name="courseDuration"
                      value={editFormData.courseDuration}
                      onChange={handleEditChange}
                      required
                      placeholder="e.g. 2 Years"
                      className="w-full rounded-xl border border-gray-200 bg-[#FAFBFA] px-4 py-3.5 text-sm outline-none transition focus:border-[#198754] focus:bg-white focus:ring-4 focus:ring-green-100"
                    />
                  </div>

                  {/* COURSE SESSION */}
                  <div className="md:col-span-2">
                    <label className="mb-2 block text-sm font-semibold text-gray-700">
                      Course Session
                      <span className="ml-1 text-red-500">*</span>
                    </label>

                    <input
                      type="text"
                      name="courseSession"
                      value={editFormData.courseSession}
                      onChange={handleEditChange}
                      required
                      placeholder="e.g. 2026–2028"
                      maxLength={30}
                      className="w-full rounded-xl border border-gray-200 bg-[#FAFBFA] px-4 py-3.5 text-sm outline-none transition focus:border-[#198754] focus:bg-white focus:ring-4 focus:ring-green-100"
                    />

                    <p className="mt-2 text-xs text-gray-400">
                      Enter the academic session, for example
                      2026–2028.
                    </p>
                  </div>
                </div>

                {/* DESCRIPTION */}
                <div className="mt-6">
                  <label className="mb-2 block text-sm font-semibold text-gray-700">
                    Course Description
                  </label>

                  <textarea
                    name="courseDescription"
                    value={editFormData.courseDescription}
                    onChange={handleEditChange}
                    rows="6"
                    placeholder="Enter course description..."
                    className="w-full resize-none rounded-2xl border border-gray-200 bg-[#FAFBFA] px-4 py-4 text-sm outline-none transition focus:border-[#198754] focus:bg-white focus:ring-4 focus:ring-green-100"
                  />
                </div>
              </div>

              {/* BUTTONS */}
              <div className="mt-8 flex flex-col-reverse gap-3 border-t border-gray-100 pt-6 sm:flex-row sm:justify-end">
                <button
                  type="button"
                  onClick={handleCloseEdit}
                  disabled={editLoading}
                  className="rounded-xl border border-gray-200 bg-white px-6 py-3.5 font-semibold text-gray-600 transition hover:bg-gray-50 disabled:opacity-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={editLoading}
                  className="rounded-xl bg-[#0F5132] px-7 py-3.5 font-semibold text-white shadow-lg shadow-green-900/10 transition hover:bg-[#198754] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {editLoading
                    ? "Updating..."
                    : "Update Course"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminLayout>
  );
};

export default Courses;
