import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";
import AdminLayout from "../components/AdminLayout";

const initialFormData = {
  courseName: "",
  courseDuration: "",
  courseSession: "",
  courseDescription: "",
  courseImage: null,
};

const AddCourse = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState(initialFormData);
  const [imagePreview, setImagePreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({
    type: "",
    text: "",
  });

  // =========================
  // HANDLE INPUT CHANGE
  // =========================
  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  // =========================
  // HANDLE IMAGE
  // =========================
  const handleImageChange = (e) => {
    const file = e.target.files?.[0];

    if (!file) return;

    const allowedTypes = [
      "image/jpeg",
      "image/jpg",
      "image/png",
      "image/webp",
    ];

    if (!allowedTypes.includes(file.type)) {
      setMessage({
        type: "error",
        text: "Only JPG, JPEG, PNG and WEBP images are allowed.",
      });

      e.target.value = "";
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setMessage({
        type: "error",
        text: "Image size must be less than 5MB.",
      });

      e.target.value = "";
      return;
    }

    setMessage({ type: "", text: "" });

    setFormData((previous) => ({
      ...previous,
      courseImage: file,
    }));

    setImagePreview(URL.createObjectURL(file));
  };

  // =========================
  // RESET FORM
  // =========================
  const handleReset = () => {
    if (imagePreview?.startsWith("blob:")) {
      URL.revokeObjectURL(imagePreview);
    }

    setFormData(initialFormData);
    setImagePreview(null);
    setMessage({ type: "", text: "" });

    const imageInput = document.getElementById("courseImage");

    if (imageInput) {
      imageInput.value = "";
    }
  };

  // =========================
  // SUBMIT FORM
  // =========================
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.courseName.trim()) {
      setMessage({
        type: "error",
        text: "Course name is required.",
      });
      return;
    }

    if (!formData.courseDuration.trim()) {
      setMessage({
        type: "error",
        text: "Course duration is required.",
      });
      return;
    }

    if (!formData.courseSession.trim()) {
      setMessage({
        type: "error",
        text: "Course session is required.",
      });
      return;
    }

    setLoading(true);
    setMessage({ type: "", text: "" });

    try {
      const data = new FormData();

      data.append(
        "courseName",
        formData.courseName.trim()
      );

      data.append(
        "courseDuration",
        formData.courseDuration.trim()
      );

      data.append(
        "courseSession",
        formData.courseSession.trim()
      );

      data.append(
        "courseDescription",
        formData.courseDescription.trim()
      );

      if (formData.courseImage) {
        data.append(
          "courseImage",
          formData.courseImage
        );
      }

      const response = await api.post(
        "/courses",
        data
      );

      if (response.data?.success) {
        setMessage({
          type: "success",
          text: "Course added successfully!",
        });

        if (imagePreview?.startsWith("blob:")) {
          URL.revokeObjectURL(imagePreview);
        }

        setFormData(initialFormData);
        setImagePreview(null);

        const imageInput =
          document.getElementById("courseImage");

        if (imageInput) {
          imageInput.value = "";
        }
      } else {
        setMessage({
          type: "error",
          text:
            response.data?.message ||
            "Failed to add course.",
        });
      }
    } catch (error) {
      console.error("Add Course Error:", error);

      setMessage({
        type: "error",
        text:
          error.response?.data?.message ||
          "Failed to add course.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <AdminLayout title="Add Course">

      {/* MAIN BACKGROUND */}
      <div className="min-h-screen bg-[#F5F7F4] px-3 py-4 md:px-6 md:py-6">

        <div className="mx-auto max-w-7xl">

          {/* ================= HEADER ================= */}

          <div className="mb-6 flex flex-col gap-5 rounded-[24px] bg-white p-6 shadow-sm md:flex-row md:items-center md:justify-between">

            <div>
              <div className="mb-2 flex items-center gap-3">

                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#0F5132] text-2xl text-white">
                  📚
                </div>

                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-[#198754]">
                    Course Management
                  </p>

                  <h1 className="text-2xl font-bold text-gray-900 md:text-3xl">
                    Create New Course
                  </h1>
                </div>

              </div>

              <p className="ml-0 text-sm text-gray-400 md:ml-[60px]">
                Add and manage courses for your institute.
              </p>
            </div>

            <button
              type="button"
              onClick={() => navigate("/courses")}
              className="flex items-center justify-center gap-2 rounded-2xl border border-[#0F5132] px-5 py-3 text-sm font-semibold text-[#0F5132] transition hover:bg-[#0F5132] hover:text-white"
            >
              <span>📚</span>
              View Courses
            </button>

          </div>


          {/* ================= MESSAGE ================= */}

          {message.text && (
            <div
              className={`mb-6 flex items-center gap-3 rounded-2xl border p-4 text-sm font-semibold shadow-sm ${
                message.type === "success"
                  ? "border-green-200 bg-green-50 text-green-700"
                  : "border-red-200 bg-red-50 text-red-700"
              }`}
            >
              <span className="text-xl">
                {message.type === "success" ? "✓" : "⚠"}
              </span>

              <span>{message.text}</span>
            </div>
          )}


          {/* ================= FORM CARD ================= */}

          <div className="overflow-hidden rounded-[28px] bg-white shadow-sm">

            {/* CARD HEADER */}

            <div className="border-b border-gray-100 px-6 py-6">

              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">

                <div className="flex items-center gap-4">

                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#EAF5EE] text-2xl">
                    🎓
                  </div>

                  <div>
                    <h2 className="text-xl font-bold text-gray-900">
                      Course Information
                    </h2>

                    <p className="mt-1 text-sm text-gray-400">
                      Enter complete information about your course.
                    </p>
                  </div>

                </div>

                <div className="rounded-full bg-[#EAF5EE] px-4 py-2 text-xs font-semibold text-[#198754]">
                  New Course
                </div>

              </div>

            </div>


            <form
              onSubmit={handleSubmit}
              className="p-5 md:p-8"
            >

              {/* ================= COURSE IMAGE ================= */}

              <div className="mb-10">

                <div className="mb-5 flex items-center gap-3">

                  <div className="h-9 w-9 rounded-full bg-[#0F5132] text-center leading-9 text-sm font-bold text-white">
                    01
                  </div>

                  <div>
                    <h3 className="font-bold text-gray-900">
                      Course Image
                    </h3>

                    <p className="text-xs text-gray-400">
                      Upload an image for this course
                    </p>
                  </div>

                </div>


                <div className="grid gap-6 lg:grid-cols-2">

                  {/* IMAGE PREVIEW */}

                  <div className="rounded-[22px] bg-[#F7F9F7] p-5">

                    <p className="mb-4 text-sm font-semibold text-gray-700">
                      Image Preview
                    </p>

                    <div className="flex h-64 w-full items-center justify-center overflow-hidden rounded-2xl border border-dashed border-gray-300 bg-white">

                      {imagePreview ? (
                        <img
                          src={imagePreview}
                          alt="Course Preview"
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="text-center">

                          <div className="mb-3 text-6xl">
                            🖼️
                          </div>

                          <p className="font-medium text-gray-500">
                            No Image Selected
                          </p>

                          <p className="mt-1 text-xs text-gray-400">
                            Your course image will appear here
                          </p>

                        </div>
                      )}

                    </div>

                  </div>


                  {/* UPLOAD AREA */}

                  <div className="rounded-[22px] bg-[#F7F9F7] p-5">

                    <p className="mb-4 text-sm font-semibold text-gray-700">
                      Upload Course Image
                    </p>

                    <label
                      htmlFor="courseImage"
                      className="flex min-h-64 cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-[#B7D4C1] bg-white p-6 text-center transition hover:border-[#198754] hover:bg-[#F5FBF7]"
                    >

                      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-[#EAF5EE] text-3xl">
                        ☁️
                      </div>

                      <p className="font-semibold text-gray-700">
                        Click to upload image
                      </p>

                      <p className="mt-2 text-xs text-gray-400">
                        JPG, JPEG, PNG or WEBP
                      </p>

                      <p className="mt-1 text-xs text-gray-400">
                        Maximum size: 5MB
                      </p>

                    </label>

                    <input
                      id="courseImage"
                      type="file"
                      name="courseImage"
                      accept="image/jpeg,image/jpg,image/png,image/webp"
                      onChange={handleImageChange}
                      className="hidden"
                    />

                  </div>

                </div>

              </div>


              {/* ================= COURSE DETAILS ================= */}

              <div>

                <div className="mb-5 flex items-center gap-3">

                  <div className="h-9 w-9 rounded-full bg-[#0F5132] text-center leading-9 text-sm font-bold text-white">
                    02
                  </div>

                  <div>
                    <h3 className="font-bold text-gray-900">
                      Course Details
                    </h3>

                    <p className="text-xs text-gray-400">
                      Enter basic course information
                    </p>
                  </div>

                </div>


                {/* INPUTS */}

                <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">

                  {/* COURSE NAME */}

                  <div className="lg:col-span-1">

                    <label className="mb-2 block text-sm font-semibold text-gray-700">
                      Course Name
                      <span className="ml-1 text-red-500">*</span>
                    </label>

                    <input
                      type="text"
                      name="courseName"
                      value={formData.courseName}
                      onChange={handleChange}
                      placeholder="Enter course name"
                      required
                      className="w-full rounded-xl border border-gray-200 bg-[#FAFBFA] px-4 py-3.5 text-sm text-gray-700 outline-none transition focus:border-[#198754] focus:bg-white focus:ring-4 focus:ring-green-100"
                    />

                  </div>


                  {/* COURSE DURATION */}

                  <div>

                    <label className="mb-2 block text-sm font-semibold text-gray-700">
                      Course Duration
                      <span className="ml-1 text-red-500">*</span>
                    </label>

                    <input
                      type="text"
                      name="courseDuration"
                      value={formData.courseDuration}
                      onChange={handleChange}
                      placeholder="e.g. 2 Years"
                      required
                      className="w-full rounded-xl border border-gray-200 bg-[#FAFBFA] px-4 py-3.5 text-sm text-gray-700 outline-none transition focus:border-[#198754] focus:bg-white focus:ring-4 focus:ring-green-100"
                    />

                  </div>


                  {/* COURSE SESSION */}

                  <div>

                    <label className="mb-2 block text-sm font-semibold text-gray-700">
                      Course Session
                      <span className="ml-1 text-red-500">*</span>
                    </label>

                    <input
                      type="text"
                      name="courseSession"
                      value={formData.courseSession}
                      onChange={handleChange}
                      placeholder="e.g. 2026 - 2028"
                      required
                      className="w-full rounded-xl border border-gray-200 bg-[#FAFBFA] px-4 py-3.5 text-sm text-gray-700 outline-none transition focus:border-[#198754] focus:bg-white focus:ring-4 focus:ring-green-100"
                    />

                  </div>

                </div>


                {/* DESCRIPTION */}

                <div className="mt-6">

                  <label className="mb-2 block text-sm font-semibold text-gray-700">
                    Course Description
                  </label>

                  <textarea
                    name="courseDescription"
                    value={formData.courseDescription}
                    onChange={handleChange}
                    placeholder="Write a short description about this course..."
                    rows="6"
                    className="w-full resize-none rounded-2xl border border-gray-200 bg-[#FAFBFA] px-4 py-4 text-sm text-gray-700 outline-none transition focus:border-[#198754] focus:bg-white focus:ring-4 focus:ring-green-100"
                  />

                  <p className="mt-2 text-xs text-gray-400">
                    Add course subjects, program details or other important information.
                  </p>

                </div>

              </div>


              {/* ================= FOOTER BUTTONS ================= */}

              <div className="mt-10 flex flex-col-reverse gap-3 border-t border-gray-100 pt-6 sm:flex-row sm:items-center sm:justify-between">

                <div className="text-xs text-gray-400">
                  Fields marked with
                  <span className="mx-1 text-red-500">*</span>
                  are required.
                </div>


                <div className="flex flex-col gap-3 sm:flex-row">

                  <button
                    type="button"
                    onClick={handleReset}
                    disabled={loading}
                    className="rounded-xl border border-gray-200 bg-white px-6 py-3.5 text-sm font-semibold text-gray-600 transition hover:bg-gray-50 disabled:opacity-50"
                  >
                    Reset
                  </button>


                  <button
                    type="button"
                    onClick={() => navigate("/courses")}
                    disabled={loading}
                    className="rounded-xl bg-[#EAF5EE] px-6 py-3.5 text-sm font-semibold text-[#0F5132] transition hover:bg-[#DDF0E3] disabled:opacity-50"
                  >
                    View Courses
                  </button>


                  <button
                    type="submit"
                    disabled={loading}
                    className="rounded-xl bg-[#0F5132] px-8 py-3.5 text-sm font-semibold text-white shadow-lg shadow-green-900/10 transition hover:bg-[#198754] disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {loading
                      ? "Adding Course..."
                      : "+ Add Course"}
                  </button>

                </div>

              </div>


            </form>

          </div>


          {/* BOTTOM INFO */}

          <div className="mt-5 flex items-center gap-3 rounded-2xl border border-[#DDEFE2] bg-[#F3FAF5] p-4">

            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#DCEFE2] text-sm">
              💡
            </div>

            <p className="text-xs leading-5 text-[#39704D]">
              <strong>Note:</strong> Make sure the course name, duration and
              session information is correct before adding the course.
            </p>

          </div>

        </div>

      </div>

    </AdminLayout>
  );
};

export default AddCourse;
