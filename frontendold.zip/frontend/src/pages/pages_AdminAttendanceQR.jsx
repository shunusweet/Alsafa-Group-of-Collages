export { default } from "./AdminAttendanceQR";
