import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";
import AdminLayout from "../components/AdminLayout";

const API_SERVER_URL = (
  import.meta.env.VITE_API_URL || "http://localhost:5000/api"
).replace(/\/api\/?$/, "");

const imageUrl = (value) =>
  !value
    ? ""
    : value.startsWith("http")
    ? value
    : `${API_SERVER_URL}${value.startsWith("/") ? value : `/${value}`}`;

const Staffs = () => {
  const navigate = useNavigate();

  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [deleteLoading, setDeleteLoading] = useState(null);

  // Fetch Staff Records
  const fetchStaff = async () => {
    try {
      setLoading(true);
      setErrorMessage("");

      const response = await api.get("/staff");

      if (response.data?.success) {
        setStaff(response.data.staff || []);
      } else {
        setErrorMessage(
          response.data?.message || "Could not load staff."
        );
      }
    } catch (error) {
      setErrorMessage(
        error.response?.data?.message ||
          "Could not load staff. Check backend."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStaff();
  }, []);

  // Search Staff
  const filteredStaff = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();

    if (!term) return staff;

    return staff.filter((item) =>
      [
        item.staffName,
        item.fatherName,
        item.designation,
        item.cnicNo,
        item.mobileNo,
        item.address,
        item.email,
        item.salary,
      ].some((value) =>
        String(value ?? "").toLowerCase().includes(term)
      )
    );
  }, [staff, searchTerm]);

  // Delete Staff
  const deleteItem = async (item) => {
    if (
      !window.confirm(
        `Delete staff record for ${item.staffName}?`
      )
    ) {
      return;
    }

    setDeleteLoading(item.id);
    setErrorMessage("");

    try {
      const response = await api.delete(`/staff/${item.id}`);

      if (response.data?.success) {
        setStaff((prev) =>
          prev.filter((row) => row.id !== item.id)
        );
      } else {
        setErrorMessage(
          response.data?.message || "Delete failed."
        );
      }
    } catch (error) {
      setErrorMessage(
        error.response?.data?.message ||
          "Could not delete staff."
      );
    } finally {
      setDeleteLoading(null);
    }
  };

  return (
    <AdminLayout title="Staff Management">
      <div className="mx-auto max-w-[1600px] space-y-6">

        {/* Header */}
        <div className="overflow-hidden rounded-2xl bg-gradient-to-r from-[#0F5132] to-[#198754] p-6 text-white shadow-lg md:p-8">
          <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
            <div>
              <div className="mb-2 flex items-center gap-2 text-green-100">
                <span className="text-xl">👥</span>
                <span className="text-sm font-semibold tracking-wider">
                  ALSAFA INSTITUTE
                </span>
              </div>

              <h1 className="text-2xl font-bold md:text-3xl">
                Staff Management
              </h1>

              <p className="mt-2 text-sm text-green-100 md:text-base">
                Manage staff details, salary and account information.
              </p>
            </div>

            <button
              onClick={() => navigate("/staff/add")}
              className="rounded-xl bg-white px-5 py-3 font-bold text-[#0F5132] shadow-md transition hover:bg-green-50 hover:shadow-lg"
            >
              + Add New Staff
            </button>
          </div>

          {/* Statistics */}
          <div className="mt-7 grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="rounded-xl border border-white/20 bg-white/10 p-4 backdrop-blur-sm">
              <p className="text-sm text-green-100">
                Total Staff
              </p>
              <p className="mt-2 text-3xl font-bold">
                {staff.length}
              </p>
            </div>

            <div className="rounded-xl border border-white/20 bg-white/10 p-4 backdrop-blur-sm">
              <p className="text-sm text-green-100">
                Matching Search
              </p>
              <p className="mt-2 text-3xl font-bold">
                {filteredStaff.length}
              </p>
            </div>

            <div className="rounded-xl border border-white/20 bg-white/10 p-4 backdrop-blur-sm">
              <p className="text-sm text-green-100">
                Records Status
              </p>
              <p className="mt-2 text-2xl font-bold">
                Staff List
              </p>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {errorMessage && (
          <div
            role="alert"
            className="flex items-center justify-between rounded-xl border border-red-200 bg-red-50 px-5 py-4 text-sm font-medium text-red-700"
          >
            <span>{errorMessage}</span>

            <button
              onClick={() => setErrorMessage("")}
              className="ml-3 font-bold"
            >
              ✕
            </button>
          </div>
        )}

        {/* Staff Table */}
        <div className="rounded-2xl border border-green-100 bg-white p-5 shadow-sm md:p-6">

          {/* Table Heading and Search */}
          <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-xl font-bold text-gray-800">
                All Staff Records
              </h2>

              <p className="mt-1 text-sm text-gray-500">
                Search by name, CNIC, mobile, salary or email.
              </p>
            </div>

            <div className="relative w-full md:max-w-sm">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                🔍
              </span>

              <input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search staff..."
                className="w-full rounded-xl border border-gray-200 bg-gray-50 py-3 pl-11 pr-4 text-sm outline-none transition focus:border-[#198754] focus:bg-white focus:ring-4 focus:ring-green-100"
              />
            </div>
          </div>

          {/* Loading */}
          {loading ? (
            <div className="flex flex-col items-center justify-center py-16">
              <div className="h-10 w-10 animate-spin rounded-full border-4 border-green-100 border-t-[#198754]" />
              <p className="mt-4 text-sm font-medium text-gray-500">
                Loading staff records...
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border border-green-100">
              <table className="min-w-[1300px] w-full text-left text-sm">

                <thead className="bg-[#EAF5EE] text-xs uppercase tracking-wide text-[#0F5132]">
                  <tr>
                    {[
                      "Staff",
                      "Father Name",
                      "Designation",
                      "CNIC",
                      "Mobile",
                      "Salary",
                      "Email",
                      "Address",
                      "CNIC Front",
                      "CNIC Back",
                      "Actions",
                    ].map((heading) => (
                      <th
                        key={heading}
                        className="whitespace-nowrap px-4 py-4 font-bold"
                      >
                        {heading}
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody className="divide-y divide-green-50">

                  {filteredStaff.map((item) => (
                    <tr
                      key={item.id}
                      className="transition hover:bg-[#F5FAF6]"
                    >
                      {/* Staff Name and Image */}
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-3">
                          {item.image ? (
                            <img
                              src={imageUrl(item.image)}
                              alt={item.staffName || "Staff"}
                              className="h-11 w-11 rounded-full border-2 border-green-100 object-cover"
                            />
                          ) : (
                            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-green-100 text-lg text-[#0F5132]">
                              👤
                            </div>
                          )}

                          <div className="font-bold text-gray-800">
                            {item.staffName || "—"}
                          </div>
                        </div>
                      </td>

                      <td className="px-4 py-4 text-gray-600">
                        {item.fatherName || "—"}
                      </td>

                      <td className="px-4 py-4">
                        <span className="rounded-lg bg-green-50 px-3 py-1.5 font-semibold text-[#0F5132]">
                          {item.designation || "—"}
                        </span>
                      </td>

                      <td className="whitespace-nowrap px-4 py-4 text-gray-600">
                        {item.cnicNo || "—"}
                      </td>

                      <td className="whitespace-nowrap px-4 py-4 text-gray-600">
                        {item.mobileNo || "—"}
                      </td>

                      <td className="whitespace-nowrap px-4 py-4 font-bold text-[#0F5132]">
                        {item.salary == null
                          ? "—"
                          : `Rs. ${Number(item.salary).toLocaleString("en-PK")}`}
                      </td>

                      <td className="px-4 py-4 text-gray-600">
                        {item.email || "—"}
                      </td>

                      <td className="max-w-[220px] px-4 py-4 text-gray-600">
                        {item.address || "—"}
                      </td>

                      {/* CNIC Front */}
                      <td className="px-4 py-4">
                        {item.cnicImageFront ? (
                          <a
                            href={imageUrl(item.cnicImageFront)}
                            target="_blank"
                            rel="noreferrer"
                            className="whitespace-nowrap font-bold text-[#198754] hover:underline"
                          >
                            View Front
                          </a>
                        ) : (
                          "—"
                        )}
                      </td>

                      {/* CNIC Back */}
                      <td className="px-4 py-4">
                        {item.cnicImageBack ? (
                          <a
                            href={imageUrl(item.cnicImageBack)}
                            target="_blank"
                            rel="noreferrer"
                            className="whitespace-nowrap font-bold text-[#198754] hover:underline"
                          >
                            View Back
                          </a>
                        ) : (
                          "—"
                        )}
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-4">
                        <div className="flex gap-2">
                          <button
                            onClick={() =>
                              navigate(`/staff/edit/${item.id}`)
                            }
                            className="rounded-lg bg-green-50 px-3 py-2 font-bold text-[#0F5132] transition hover:bg-green-100"
                          >
                            Edit
                          </button>

                          <button
                            disabled={deleteLoading === item.id}
                            onClick={() => deleteItem(item)}
                            className="rounded-lg bg-red-50 px-3 py-2 font-bold text-red-600 transition hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            {deleteLoading === item.id
                              ? "..."
                              : "Delete"}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}

                  {/* Empty State */}
                  {!filteredStaff.length && (
                    <tr>
                      <td
                        colSpan={11}
                        className="px-4 py-16 text-center"
                      >
                        <div className="text-4xl">👥</div>

                        <h3 className="mt-3 font-bold text-gray-700">
                          No Staff Records Found
                        </h3>

                        <p className="mt-1 text-sm text-gray-500">
                          Try another search or add a new staff member.
                        </p>

                        {!searchTerm && (
                          <button
                            onClick={() => navigate("/staff/add")}
                            className="mt-4 rounded-lg bg-[#198754] px-5 py-2.5 font-bold text-white transition hover:bg-[#0F5132]"
                          >
                            + Add Staff
                          </button>
                        )}
                      </td>
                    </tr>
                  )}

                </tbody>
              </table>
            </div>
          )}

          {/* Refresh Button */}
          {!loading && (
            <div className="mt-5 flex justify-end">
              <button
                onClick={fetchStaff}
                className="rounded-lg border border-green-200 bg-green-50 px-4 py-2.5 text-sm font-bold text-[#0F5132] transition hover:bg-green-100"
              >
                ↻ Refresh Staff List
              </button>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
};

export default Staffs;