import { useEffect, useState } from "react";
import {
  useNavigate,
  useSearchParams
} from "react-router-dom";

import AdminLayout from "../components/AdminLayout";
import api from "../services/api";

// ==========================================
// CURRENT MONTH: YYYY-MM
// ==========================================

const getCurrentMonth = () => {
  const now = new Date();

  return (
    now.getFullYear() +
    "-" +
    String(now.getMonth() + 1).padStart(2, "0")
  );
};

// ==========================================
// CURRENCY FORMAT
// ==========================================

const formatCurrency = (amount) =>
  "Rs " +
  Number(amount || 0).toLocaleString("en-PK", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

// ==========================================
// STAT CARD
// ==========================================

const StatCard = ({
  label,
  value,
  icon,
  subtitle,
  dark = false
}) => {
  return (
    <div
      className={`rounded-2xl border p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg ${
        dark
          ? "border-transparent bg-gradient-to-br from-[#104e36] to-[#25835d] text-white shadow-md"
          : "border-gray-100 bg-white shadow-sm"
      }`}
    >
      <div className="flex items-center justify-between">
        <p
          className={`text-sm font-medium ${
            dark
              ? "text-white/80"
              : "text-gray-500"
          }`}
        >
          {label}
        </p>

        <div
          className={`flex h-11 w-11 items-center justify-center rounded-full text-xl ${
            dark
              ? "bg-white/15 text-white"
              : "bg-emerald-50 text-emerald-800"
          }`}
        >
          {icon}
        </div>
      </div>

      <h2
        className={`mt-4 text-2xl font-bold tracking-tight md:text-3xl ${
          dark
            ? "text-white"
            : "text-gray-900"
        }`}
      >
        {value}
      </h2>

      <p
        className={`mt-2 text-xs ${
          dark
            ? "text-white/70"
            : "text-gray-400"
        }`}
      >
        {subtitle}
      </p>
    </div>
  );
};

// ==========================================
// ADD FEE COMPONENT
// ==========================================

const AddFee = () => {
  const navigate = useNavigate();

  const [searchParams] = useSearchParams();

  const [students, setStudents] =
    useState([]);

  const [courses, setCourses] =
    useState([]);

  const [feeAccounts, setFeeAccounts] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [saving, setSaving] =
    useState(false);

  const [error, setError] =
    useState("");

  const [formData, setFormData] =
    useState({
      studentId:
        searchParams.get("studentId") || "",
      totalFee: "",
      month: getCurrentMonth(),
      amountPaid: "",
      remarks: ""
    });

  // ==========================================
  // LOAD STUDENTS, COURSES AND EXISTING FEES
  // ==========================================

  useEffect(() => {
    const loadFormData = async () => {
      try {
        setLoading(true);
        setError("");

        const [
          studentResponse,
          courseResponse,
          feeResponse
        ] = await Promise.all([
          api.get("/students"),
          api.get("/courses"),
          api.get("/fees")
        ]);

        const studentData =
          studentResponse.data?.students ||
          studentResponse.data?.data ||
          [];

        const courseData =
          courseResponse.data?.courses ||
          [];

        const feeData =
          feeResponse.data?.fees ||
          [];

        setStudents(studentData);
        setCourses(courseData);
        setFeeAccounts(feeData);

        const requestedId =
          searchParams.get("studentId");

        if (requestedId) {
          const existing = feeData.find(
            (fee) =>
              Number(fee.studentId) ===
              Number(requestedId)
          );

          const paid = existing
            ? (existing.payments || []).reduce(
                (sum, payment) =>
                  sum +
                  Number(payment.amountPaid || 0),
                0
              )
            : 0;

          const balance = existing
            ? Math.max(
                0,
                Number(existing.totalFee) - paid
              )
            : 0;

          setFormData((previous) => ({
            ...previous,
            studentId: requestedId,
            totalFee: existing
              ? String(existing.totalFee)
              : "",
            amountPaid:
              existing && balance > 0
                ? balance.toFixed(2)
                : ""
          }));
        }
      } catch (err) {
        console.error(
          "Load Fee Form Data Error:",
          err
        );

        setError(
          err.response?.data?.message ||
            "Unable to load students, courses or fee accounts."
        );
      } finally {
        setLoading(false);
      }
    };

    loadFormData();
  }, [searchParams]);

  // ==========================================
  // SELECTED STUDENT AND FEE ACCOUNT
  // ==========================================

  const selectedStudent = students.find(
    (student) =>
      Number(student.id) ===
      Number(formData.studentId)
  );

  const existingFee = feeAccounts.find(
    (fee) =>
      Number(fee.studentId) ===
      Number(formData.studentId)
  );

  const selectedCourse = courses.find(
    (course) =>
      course.courseName?.trim().toLowerCase() ===
      selectedStudent?.course?.trim().toLowerCase()
  );

  const previousPaid = existingFee
    ? (existingFee.payments || []).reduce(
        (sum, payment) =>
          sum +
          Number(payment.amountPaid || 0),
        0
      )
    : 0;

  const remainingBalance = existingFee
    ? Math.max(
        0,
        Number(existingFee.totalFee) - previousPaid
      )
    : Number(formData.totalFee || 0);

  // ==========================================
  // HANDLE INPUT CHANGES
  // ==========================================

  const handleChange = (event) => {
    const { name, value } = event.target;

    if (name === "studentId") {
      const fee = feeAccounts.find(
        (item) =>
          Number(item.studentId) ===
          Number(value)
      );

      const paid = fee
        ? (fee.payments || []).reduce(
            (sum, payment) =>
              sum +
              Number(payment.amountPaid || 0),
            0
          )
        : 0;

      const balance = fee
        ? Math.max(
            0,
            Number(fee.totalFee) - paid
          )
        : 0;

      setFormData((previous) => ({
        ...previous,
        studentId: value,
        totalFee: fee
          ? String(fee.totalFee)
          : "",
        amountPaid:
          fee && balance > 0
            ? balance.toFixed(2)
            : ""
      }));
    } else {
      setFormData((previous) => ({
        ...previous,
        [name]: value
      }));
    }

    setError("");
  };

  // ==========================================
  // SUBMIT MONTHLY PAYMENT
  // ==========================================

  const handleSubmit = async (event) => {
    event.preventDefault();

    setError("");

    if (!selectedStudent) {
      setError("Please select a student.");
      return;
    }

    if (
      !existingFee &&
      Number(formData.totalFee) <= 0
    ) {
      setError(
        "Please enter the student's total fee."
      );
      return;
    }

    const amount = Number(
      formData.amountPaid
    );

    if (!Number.isFinite(amount) || amount <= 0) {
      setError(
        "Payment amount must be greater than zero."
      );
      return;
    }

    if (amount > remainingBalance + 0.001) {
      setError(
        `Payment cannot exceed the remaining balance of ${formatCurrency(
          remainingBalance
        )}.`
      );
      return;
    }

    try {
      setSaving(true);

      const response = await api.post(
        "/fees",
        {
          studentId: Number(
            formData.studentId
          ),
          totalFee: existingFee
            ? Number(existingFee.totalFee)
            : Number(formData.totalFee),
          month: formData.month,
          amountPaid: amount,
          remarks: formData.remarks.trim()
        }
      );

      if (response.data?.success) {
        navigate("/fees");
      } else {
        setError(
          response.data?.message ||
            "Failed to save fee payment."
        );
      }
    } catch (err) {
      console.error(
        "Save Fee Error:",
        err
      );

      setError(
        err.response?.data?.message ||
          "Fee could not be saved. Please check the backend."
      );
    } finally {
      setSaving(false);
    }
  };

  // ==========================================
  // INPUT STYLES
  // ==========================================

  const inputStyle =
    "w-full rounded-xl border border-gray-200 bg-[#fafbf9] px-4 py-3.5 text-sm text-gray-800 outline-none transition-all focus:border-emerald-600 focus:bg-white focus:ring-4 focus:ring-emerald-50 disabled:cursor-not-allowed disabled:bg-gray-100 disabled:text-gray-500";

  const labelStyle =
    "mb-2 block text-sm font-semibold text-gray-700";

  // ==========================================
  // UI
  // ==========================================

  return (
    <AdminLayout title="Add Fee">

      <div className="min-h-screen space-y-6 bg-[#f7f8f6] p-1">

        {/* ================================= */}
        {/* PAGE HEADER */}
        {/* ================================= */}

        <div className="flex flex-col justify-between gap-4 rounded-2xl bg-white p-5 shadow-sm md:flex-row md:items-center md:p-6">

          <div>
            <div className="mb-2 flex items-center gap-2 text-sm text-gray-400">
              <span>Dashboard</span>
              <span>/</span>
              <span>Fees</span>
              <span>/</span>
              <span className="font-medium text-emerald-700">
                Add Payment
              </span>
            </div>

            <h1 className="text-2xl font-bold tracking-tight text-gray-900 md:text-3xl">
              Add Student Fee
            </h1>

            <p className="mt-2 text-sm text-gray-400">
              Record and manage student fee payments easily.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">

            <button
              type="button"
              onClick={() => navigate("/fees")}
              className="rounded-full border border-emerald-800 bg-white px-5 py-3 text-sm font-semibold text-emerald-900 transition hover:bg-emerald-50"
            >
              View Fees
            </button>

            <button
              type="button"
              onClick={() => navigate(-1)}
              className="rounded-full bg-[#115b3d] px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-[#0b4930]"
            >
              ← Back
            </button>

          </div>
        </div>

        {/* ================================= */}
        {/* ERROR */}
        {/* ================================= */}

        {error && (
          <div className="flex items-center gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            <span className="text-lg">⚠</span>
            <span>{error}</span>
          </div>
        )}

        {/* ================================= */}
        {/* SUMMARY CARDS */}
        {/* ================================= */}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">

          <StatCard
            label="Selected Student"
            value={
              selectedStudent?.name ||
              "Not Selected"
            }
            icon="👨‍🎓"
            dark={true}
            subtitle={
              selectedStudent?.course ||
              "Select a student to continue"
            }
          />

          <StatCard
            label="Total Course Fee"
            value={
              existingFee
                ? formatCurrency(existingFee.totalFee)
                : formData.totalFee
                ? formatCurrency(formData.totalFee)
                : "Rs 0.00"
            }
            icon="💰"
            subtitle="Total fee amount"
          />

          <StatCard
            label="Remaining Balance"
            value={formatCurrency(remainingBalance)}
            icon="◷"
            subtitle={
              existingFee
                ? "Outstanding fee balance"
                : "Enter total fee first"
            }
          />

        </div>

        {/* ================================= */}
        {/* MAIN FORM */}
        {/* ================================= */}

        <form
          onSubmit={handleSubmit}
          className="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm"
        >

          {/* FORM HEADER */}

          <div className="flex flex-col justify-between gap-3 border-b border-gray-100 p-5 md:flex-row md:items-center md:p-6">

            <div>
              <h2 className="text-lg font-bold text-gray-900">
                Student & Fee Details
              </h2>

              <p className="mt-1 text-sm text-gray-400">
                Select the student and enter payment information.
              </p>
            </div>

            <div className="rounded-full bg-emerald-50 px-4 py-2 text-xs font-semibold text-emerald-800">
              Fee Payment
            </div>

          </div>

          {loading ? (

            <div className="flex flex-col items-center justify-center gap-4 py-20">

              <div className="h-10 w-10 animate-spin rounded-full border-4 border-emerald-100 border-t-emerald-700" />

              <p className="text-sm text-gray-500">
                Loading student information...
              </p>

            </div>

          ) : (

            <>

              <div className="space-y-8 p-5 md:p-7">

                {/* ================================= */}
                {/* STUDENT INFORMATION */}
                {/* ================================= */}

                <div>

                  <h3 className="mb-5 flex items-center gap-3 text-base font-bold text-gray-800">

                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 text-emerald-800">
                      👨‍🎓
                    </span>

                    Student Information

                  </h3>

                  <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">

                    {/* SELECT STUDENT */}

                    <div>

                      <label className={labelStyle}>
                        Select Student *
                      </label>

                      <select
                        name="studentId"
                        value={formData.studentId}
                        onChange={handleChange}
                        required
                        className={inputStyle}
                      >

                        <option value="">
                          Choose student
                        </option>

                        {students.map((student) => (

                          <option
                            key={student.id}
                            value={student.id}
                          >
                            {student.name}
                            {" — "}
                            {student.fatherName}
                          </option>

                        ))}

                      </select>

                    </div>

                    {/* STUDENT NAME */}

                    <div>

                      <label className={labelStyle}>
                        Student Name
                      </label>

                      <input
                        type="text"
                        value={
                          selectedStudent?.name || ""
                        }
                        readOnly
                        placeholder="Student name"
                        className={inputStyle}
                      />

                    </div>

                    {/* FATHER NAME */}

                    <div>

                      <label className={labelStyle}>
                        Father Name
                      </label>

                      <input
                        type="text"
                        value={
                          selectedStudent?.fatherName || ""
                        }
                        readOnly
                        placeholder="Father name"
                        className={inputStyle}
                      />

                    </div>

                    {/* COURSE */}

                    <div>

                      <label className={labelStyle}>
                        Course / Diploma
                      </label>

                      <input
                        type="text"
                        value={
                          selectedStudent?.course || ""
                        }
                        readOnly
                        placeholder="Course information"
                        className={inputStyle}
                      />

                    </div>

                    {/* COURSE DURATION */}

                    <div>

                      <label className={labelStyle}>
                        Course Duration
                      </label>

                      <input
                        type="text"
                        value={
                          selectedCourse?.courseDuration || ""
                        }
                        readOnly
                        placeholder="Course duration unavailable"
                        className={inputStyle}
                      />

                    </div>

                    {/* PAYMENT MONTH */}

                    <div>

                      <label className={labelStyle}>
                        Fee Month *
                      </label>

                      <input
                        type="month"
                        name="month"
                        value={formData.month}
                        onChange={handleChange}
                        required
                        className={inputStyle}
                      />

                    </div>

                  </div>

                </div>

                {/* DIVIDER */}

                <div className="border-t border-gray-100" />

                {/* ================================= */}
                {/* FEE INFORMATION */}
                {/* ================================= */}

                <div>

                  <h3 className="mb-5 flex items-center gap-3 text-base font-bold text-gray-800">

                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 text-emerald-800">
                      Rs
                    </span>

                    Fee Information

                  </h3>

                  <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">

                    {/* TOTAL FEES */}

                    <div>

                      <label className={labelStyle}>
                        Total Fees (Rs) *
                      </label>

                      <input
                        type="number"
                        name="totalFee"
                        value={formData.totalFee}
                        onChange={handleChange}
                        min="0.01"
                        step="0.01"
                        required={!existingFee}
                        disabled={Boolean(existingFee)}
                        placeholder="Enter total course fee"
                        className={inputStyle}
                      />

                      {existingFee && (
                        <p className="mt-2 text-xs text-gray-400">
                          Saved total fee cannot be changed here.
                        </p>
                      )}

                    </div>

                    {/* PREVIOUSLY PAID */}

                    <div>

                      <label className={labelStyle}>
                        Previously Paid
                      </label>

                      <div className="flex h-[52px] items-center rounded-xl border border-gray-200 bg-[#f7faf7] px-4 font-semibold text-emerald-700">
                        {formatCurrency(previousPaid)}
                      </div>

                    </div>

                    {/* REMAINING BALANCE */}

                    <div>

                      <label className={labelStyle}>
                        Remaining Balance
                      </label>

                      <div
                        className={`flex h-[52px] items-center rounded-xl border px-4 font-semibold ${
                          remainingBalance <= 0
                            ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                            : "border-red-100 bg-red-50 text-red-700"
                        }`}
                      >
                        {formatCurrency(remainingBalance)}
                      </div>

                    </div>

                    {/* AMOUNT PAID */}

                    <div>

                      <label className={labelStyle}>
                        Amount Paid (Rs) *
                      </label>

                      <input
                        type="number"
                        name="amountPaid"
                        value={formData.amountPaid}
                        onChange={handleChange}
                        min="0.01"
                        max={remainingBalance}
                        step="0.01"
                        required
                        placeholder="Enter payment amount"
                        className={inputStyle}
                      />

                    </div>

                    {/* ACCOUNT STATUS */}

                    <div>

                      <label className={labelStyle}>
                        Account Status
                      </label>

                      <div className="flex h-[52px] items-center">

                        <span
                          className={`rounded-full px-4 py-2 text-xs font-semibold ${
                            remainingBalance <= 0
                              ? "bg-emerald-100 text-emerald-700"
                              : "bg-amber-100 text-amber-700"
                          }`}
                        >
                          {remainingBalance <= 0
                            ? "✓ Cleared"
                            : "◷ Pending"}
                        </span>

                      </div>

                    </div>

                    {/* REMARKS */}

                    <div>

                      <label className={labelStyle}>
                        Remarks
                      </label>

                      <input
                        type="text"
                        name="remarks"
                        value={formData.remarks}
                        onChange={handleChange}
                        placeholder="Optional payment remarks"
                        className={inputStyle}
                      />

                    </div>

                  </div>

                </div>

                {/* ================================= */}
                {/* EXISTING ACCOUNT SUMMARY */}
                {/* ================================= */}

                {existingFee && (

                  <div className="rounded-2xl border border-emerald-100 bg-emerald-50/50 p-5">

                    <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">

                      <div>

                        <h3 className="font-bold text-emerald-950">
                          Existing Fee Account
                        </h3>

                        <p className="mt-1 text-sm text-emerald-800/70">
                          Current fee account payment summary.
                        </p>

                      </div>

                      <span
                        className={`rounded-full px-4 py-2 text-xs font-bold ${
                          remainingBalance <= 0
                            ? "bg-emerald-600 text-white"
                            : "bg-amber-100 text-amber-800"
                        }`}
                      >
                        {remainingBalance <= 0
                          ? "Fee Cleared"
                          : "Payment Pending"}
                      </span>

                    </div>

                    <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-3">

                      <div className="rounded-xl bg-white p-4 shadow-sm">

                        <p className="text-xs text-gray-400">
                          Total Fee
                        </p>

                        <p className="mt-2 text-lg font-bold text-gray-900">
                          {formatCurrency(
                            existingFee.totalFee
                          )}
                        </p>

                      </div>

                      <div className="rounded-xl bg-white p-4 shadow-sm">

                        <p className="text-xs text-gray-400">
                          Previously Paid
                        </p>

                        <p className="mt-2 text-lg font-bold text-emerald-700">
                          {formatCurrency(previousPaid)}
                        </p>

                      </div>

                      <div className="rounded-xl bg-white p-4 shadow-sm">

                        <p className="text-xs text-gray-400">
                          Remaining Balance
                        </p>

                        <p
                          className={`mt-2 text-lg font-bold ${
                            remainingBalance <= 0
                              ? "text-emerald-700"
                              : "text-red-600"
                          }`}
                        >
                          {formatCurrency(
                            remainingBalance
                          )}
                        </p>

                      </div>

                    </div>

                  </div>

                )}

              </div>

              {/* ================================= */}
              {/* FORM FOOTER */}
              {/* ================================= */}

              <div className="flex flex-col-reverse justify-between gap-3 border-t border-gray-100 bg-[#fafbf9] p-5 sm:flex-row sm:items-center md:px-7">

                <button
                  type="button"
                  onClick={() => navigate("/fees")}
                  className="rounded-full border border-gray-300 bg-white px-7 py-3 text-sm font-semibold text-gray-600 transition hover:bg-gray-100"
                >
                  Cancel
                </button>

                <div className="flex flex-col gap-3 sm:flex-row">

                  <button
                    type="button"
                    onClick={() => navigate("/fees")}
                    className="rounded-full border border-emerald-800 px-6 py-3 text-sm font-semibold text-emerald-900 transition hover:bg-emerald-50"
                  >
                    View Fees
                  </button>

                  <button
                    type="submit"
                    disabled={
                      saving ||
                      !selectedStudent ||
                      (
                        Boolean(existingFee) &&
                        remainingBalance <= 0
                      )
                    }
                    className="rounded-full bg-gradient-to-r from-[#104e36] to-[#23845d] px-8 py-3 text-sm font-semibold text-white shadow-md transition hover:shadow-lg disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {saving
                      ? "Saving Payment..."
                      : "✓ Save Fee Payment"}
                  </button>

                </div>

              </div>

            </>

          )}

        </form>

        {/* ================================= */}
        {/* BOTTOM NOTE */}
        {/* ================================= */}

        <div className="rounded-xl border border-emerald-100 bg-emerald-50/60 p-4">

          <p className="text-xs leading-6 text-emerald-900">
            <strong>Note:</strong> Please verify the student details,
            fee amount and payment information before saving the
            transaction. Payment amount cannot exceed the remaining
            balance.
          </p>

        </div>

      </div>

    </AdminLayout>
  );
};

export default AddFee;