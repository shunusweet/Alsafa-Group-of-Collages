
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";
import AdminLayout from "../components/AdminLayout";

const initialForm = {
  staffName: "",
  fatherName: "",
  designation: "",
  cnicNo: "",
  mobileNo: "",
  address: "",
  salary: "",
  email: "",
  password: "",
  image: null,
  cnicImageFront: null,
  cnicImageBack: null,
};

const imageFields = [
  { title: "Staff Image", fieldName: "image", inputId: "staffImage", icon: "👤" },
  { title: "CNIC Front", fieldName: "cnicImageFront", inputId: "cnicImageFront", icon: "🪪" },
  { title: "CNIC Back", fieldName: "cnicImageBack", inputId: "cnicImageBack", icon: "🪪" },
];

const AddStaff = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState(initialForm);
  const [previews, setPreviews] = useState({
    image: null,
    cnicImageFront: null,
    cnicImageBack: null,
  });

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
    setErrorMessage("");
  };

  const handleImageChange = (e, fieldName) => {
    const file = e.target.files?.[0];

    setErrorMessage("");

    if (!file) return;

    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      setErrorMessage("Only JPG, JPEG, PNG and WEBP images are allowed.");
      e.target.value = "";
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setErrorMessage("Each image must be 5MB or smaller.");
      e.target.value = "";
      return;
    }

    setPreviews((prev) => {
      if (prev[fieldName]?.startsWith("blob:")) {
        URL.revokeObjectURL(prev[fieldName]);
      }

      return {
        ...prev,
        [fieldName]: URL.createObjectURL(file),
      };
    });

    setFormData((prev) => ({
      ...prev,
      [fieldName]: file,
    }));
  };

  const handleReset = () => {
    Object.values(previews).forEach((url) => {
      if (url?.startsWith("blob:")) URL.revokeObjectURL(url);
    });

    setFormData(initialForm);
    setPreviews({
      image: null,
      cnicImageFront: null,
      cnicImageBack: null,
    });
    setErrorMessage("");
    setSuccessMessage("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setErrorMessage("");
    setSuccessMessage("");

    for (const [key, label] of [
      ["staffName", "staff name"],
      ["fatherName", "father name"],
      ["designation", "designation"],
      ["cnicNo", "CNIC number"],
      ["mobileNo", "mobile number"],
      ["address", "address"],
      ["email", "email"],
      ["password", "password"],
    ]) {
      if (!String(formData[key] || "").trim()) {
        setErrorMessage(`Please enter ${label}.`);
        return;
      }
    }

    if (formData.password.length < 8) {
      setErrorMessage("Password must be at least 8 characters.");
      return;
    }

    if (
      formData.salary === "" ||
      !Number.isFinite(Number(formData.salary)) ||
      Number(formData.salary) < 0
    ) {
      setErrorMessage("Please enter a valid non-negative salary.");
      return;
    }

    if (!formData.image || !formData.cnicImageFront || !formData.cnicImageBack) {
      setErrorMessage("Please choose staff image, CNIC front and CNIC back images.");
      return;
    }

    const data = new FormData();

    [
      "staffName",
      "fatherName",
      "designation",
      "cnicNo",
      "mobileNo",
      "address",
      "salary",
      "email",
      "password",
    ].forEach((key) => {
      data.append(key, String(formData[key]).trim());
    });

    ["image", "cnicImageFront", "cnicImageBack"].forEach((key) => {
      data.append(key, formData[key]);
    });

    setLoading(true);

    try {
      const response = await api.post("/staff", data);

      if (response.data?.success) {
        setSuccessMessage("Staff added successfully.");

        setTimeout(() => navigate("/staff"), 700);
      } else {
        setErrorMessage(response.data?.message || "Failed to add staff.");
      }
    } catch (error) {
      console.error("Add Staff Error:", error);
      console.error("Backend Response:", error.response?.data);

      if (error.response?.data?.message) {
        setErrorMessage(error.response.data.message);
      } else if (error.response?.data?.error) {
        setErrorMessage(error.response.data.error);
      } else if (error.code === "ERR_NETWORK") {
        setErrorMessage("Backend connection failed. Please check your server.");
      } else {
        setErrorMessage(error.message || "Staff could not be saved.");
      }
    } finally {
      setLoading(false);
    }
  };

  const inputClass =
    "w-full rounded-xl border border-gray-200 bg-[#FAFBFA] px-4 py-3.5 text-sm text-gray-800 outline-none transition focus:border-[#198754] focus:bg-white focus:ring-4 focus:ring-green-100";

  const fields = [
    ["staffName", "Staff Name", "Enter staff name", "text"],
    ["fatherName", "Father Name", "Enter father name", "text"],
    ["designation", "Designation", "e.g. Admin Officer, Lecturer", "text"],
    ["cnicNo", "CNIC Number", "42101-1234567-1", "text"],
    ["mobileNo", "Mobile Number", "03XX-XXXXXXX", "tel"],
    ["salary", "Monthly Salary", "Enter salary amount", "number"],
    ["email", "Email", "staff@example.com", "email"],
    ["password", "Password", "Minimum 8 characters", "password"],
  ];

  return (
    <AdminLayout title="Add Staff">
      <div className="min-h-screen bg-[#F5F7F4] p-3 md:p-6">
        <div className="mx-auto max-w-[1400px] space-y-6">

          {/* HEADER */}
          <div className="rounded-[24px] bg-gradient-to-r from-[#0F5132] to-[#198754] p-6 text-white shadow-lg md:p-8">
            <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
              <div>
                <div className="mb-3 flex items-center gap-3">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15 text-3xl">
                    👨‍💼
                  </div>

                  <div>
                    <p className="text-xs font-semibold uppercase tracking-widest text-green-100">
                      Staff Management
                    </p>
                    <h1 className="text-2xl font-bold md:text-3xl">
                      Add New Staff
                    </h1>
                  </div>
                </div>

                <p className="text-sm text-green-100">
                  Register new employees and manage their documents.
                </p>
              </div>

              <button
                type="button"
                onClick={() => navigate("/staff")}
                className="rounded-xl bg-white px-6 py-3.5 font-semibold text-[#0F5132] transition hover:bg-green-50"
              >
                View All Staff →
              </button>
            </div>
          </div>

          {/* MESSAGES */}
          {errorMessage && (
            <div
              role="alert"
              className="rounded-2xl border border-red-200 bg-red-50 px-5 py-4 text-red-700"
            >
              <strong>⚠ Please check the form</strong>
              <p className="mt-1 text-sm">{errorMessage}</p>
            </div>
          )}

          {successMessage && (
            <div
              role="status"
              className="rounded-2xl border border-green-200 bg-green-50 px-5 py-4 font-semibold text-green-700"
            >
              ✓ {successMessage}
            </div>
          )}

          <form
            onSubmit={handleSubmit}
            className="overflow-hidden rounded-[26px] border border-gray-100 bg-white shadow-sm"
          >
            {/* FORM HEADING */}
            <div className="border-b border-gray-100 bg-[#F7F9F7] px-6 py-6 md:px-8">
              <h2 className="text-xl font-bold text-gray-900">
                Staff Registration Form
              </h2>
              <p className="mt-1 text-sm text-gray-400">
                Enter all required information carefully.
              </p>
            </div>

            <div className="space-y-9 p-6 md:p-8">

              {/* PERSONAL DETAILS */}
              <section>
                <div className="mb-6 flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#0F5132] font-bold text-white">
                    01
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">
                      Personal & Account Information
                    </h3>
                    <p className="text-xs text-gray-400">
                      Basic employee and login information
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                  {fields.map(([name, label, placeholder, type]) => (
                    <div key={name}>
                      <label
                        htmlFor={name}
                        className="mb-2 block text-sm font-semibold text-gray-700"
                      >
                        {label} <span className="text-red-500">*</span>
                      </label>

                      <input
                        id={name}
                        name={name}
                        type={type}
                        value={formData[name]}
                        onChange={handleChange}
                        placeholder={placeholder}
                        min={name === "salary" ? "0" : undefined}
                        step={name === "salary" ? "0.01" : undefined}
                        minLength={name === "password" ? 8 : undefined}
                        maxLength={name === "cnicNo" ? 15 : undefined}
                        autoComplete={
                          name === "password"
                            ? "new-password"
                            : name === "email"
                            ? "email"
                            : "off"
                        }
                        className={inputClass}
                      />
                    </div>
                  ))}
                </div>

                <div className="mt-5">
                  <label
                    htmlFor="address"
                    className="mb-2 block text-sm font-semibold text-gray-700"
                  >
                    Complete Address <span className="text-red-500">*</span>
                  </label>

                  <textarea
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    placeholder="Enter complete staff address"
                    rows={4}
                    className={inputClass}
                  />
                </div>
              </section>

              {/* DOCUMENTS */}
              <section className="border-t border-gray-100 pt-8">
                <div className="mb-6 flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#0F5132] font-bold text-white">
                    02
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-gray-900">
                      Staff Documents
                    </h3>
                    <p className="text-xs text-gray-400">
                      Upload staff photograph and CNIC documents
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
                  {imageFields.map(({ title, fieldName, inputId, icon }) => (
                    <div
                      key={fieldName}
                      className="rounded-2xl border border-gray-200 bg-white p-5 transition hover:border-[#198754] hover:shadow-lg"
                    >
                      <label
                        htmlFor={inputId}
                        className="mb-4 block font-bold text-gray-800"
                      >
                        {title} <span className="text-red-500">*</span>
                      </label>

                      <div className="mb-4 flex h-52 items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed border-[#B7D4C1] bg-[#F7FAF7]">
                        {previews[fieldName] ? (
                          <img
                            src={previews[fieldName]}
                            alt={`${title} preview`}
                            className="h-full w-full object-contain"
                          />
                        ) : (
                          <div className="text-center">
                            <div className="mb-3 text-5xl">{icon}</div>
                            <p className="text-sm font-medium text-gray-400">
                              No file selected
                            </p>
                          </div>
                        )}
                      </div>

                      <input
                        id={inputId}
                        type="file"
                        accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                        onChange={(e) => handleImageChange(e, fieldName)}
                        className="w-full cursor-pointer text-sm text-gray-600 file:mr-3 file:rounded-lg file:border-0 file:bg-[#EAF5EE] file:px-3 file:py-2 file:font-semibold file:text-[#0F5132] hover:file:bg-[#DDF0E3]"
                      />

                      <p className="mt-3 text-xs text-gray-400">
                        JPG, PNG or WEBP • Maximum 5MB
                      </p>
                    </div>
                  ))}
                </div>
              </section>

              {/* FORM BUTTONS */}
              <div className="flex flex-col gap-3 border-t border-gray-100 pt-7 sm:flex-row sm:justify-end">
                <button
                  type="button"
                  onClick={handleReset}
                  disabled={loading}
                  className="rounded-xl border border-gray-200 px-7 py-3.5 font-semibold text-gray-600 transition hover:bg-gray-50 disabled:opacity-50"
                >
                  Reset Form
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  className="rounded-xl bg-[#0F5132] px-8 py-3.5 font-bold text-white shadow-lg shadow-green-900/10 transition hover:bg-[#198754] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {loading ? "Saving Staff..." : "✓ Save Staff"}
                </button>
              </div>
            </div>
          </form>

          <div className="rounded-2xl border border-[#DDEFE2] bg-[#F3FAF5] p-4 text-sm text-[#39704D]">
            💡 <strong>Note:</strong> All marked fields are required.
            Upload all three images before submitting the registration form.
          </div>

        </div>
      </div>
    </AdminLayout>
  );
};

export default AddStaff;
