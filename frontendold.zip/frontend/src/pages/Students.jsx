import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";
import AdminLayout from "../components/AdminLayout";

// =====================================================
// API SERVER URL
// =====================================================

const API_SERVER_URL = (
  import.meta.env.VITE_API_URL || "http://localhost:5000/api"
).replace(/\/api\/?$/, "");

// =====================================================
// IMAGE URL
// =====================================================

const getImageUrl = (image) => {
  if (!image) return "";

  if (image.startsWith("http")) {
    return image;
  }

  return `${API_SERVER_URL}${
    image.startsWith("/") ? image : `/${image}`
  }`;
};

// =====================================================
// GET INITIALS
// =====================================================

const getInitials = (name = "") => {
  const words = String(name).trim().split(" ").filter(Boolean);

  if (words.length === 0) return "S";

  if (words.length === 1) {
    return words[0].charAt(0).toUpperCase();
  }

  return (
    words[0].charAt(0) +
    words[words.length - 1].charAt(0)
  ).toUpperCase();
};

// =====================================================
// GREEN THEME CLASSES
// =====================================================

const GREEN_BUTTON =
  "bg-[#176B49] text-white hover:bg-[#10583A]";

const GREEN_FOCUS =
  "focus:border-[#207A52] focus:ring-2 focus:ring-[#207A52]/15";

const INPUT_CLASS =
  `w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-3
   text-sm text-gray-800 outline-none transition
   focus:bg-white ${GREEN_FOCUS}`;

// =====================================================
// STUDENTS COMPONENT
// =====================================================

const Students = () => {
  const navigate = useNavigate();

  // ===================================================
  // STATES
  // ===================================================

  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  const [searchTerm, setSearchTerm] = useState("");
  const [courseFilter, setCourseFilter] = useState("");

  const [editingStudent, setEditingStudent] = useState(null);

  const [editForm, setEditForm] = useState({
    name: "",
    fatherName: "",
    cnic: "",
    qualification: "",
    domicile: "",
    email: "",
    password: "",
    phone: "",
    parentPhone: "",
    gender: "",
    course: "",
    address: "",
    status: "Active",
    image: null,
  });

  const [editImagePreview, setEditImagePreview] = useState("");
  const [message, setMessage] = useState({
    type: "",
    text: "",
  });

  const [updating, setUpdating] = useState(false);

  // ===================================================
  // FETCH STUDENTS
  // ===================================================

  const fetchStudents = async () => {
    try {
      setLoading(true);

      const response = await api.get("/students");

      const studentList =
        response.data?.students ??
        response.data?.data ??
        [];

      setStudents(
        Array.isArray(studentList) ? studentList : []
      );
    } catch (error) {
      console.error("Fetch students error:", error);

      setMessage({
        type: "error",
        text:
          error.response?.data?.message ||
          "Unable to load students.",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  // ===================================================
  // COURSE OPTIONS
  // ===================================================

  const courseOptions = useMemo(() => {
    return [
      ...new Set(
        students
          .map((student) => student.course)
          .filter(Boolean)
      ),
    ].sort();
  }, [students]);

  // ===================================================
  // FILTER STUDENTS
  // ===================================================

  const filteredStudents = useMemo(() => {
    const search = searchTerm.toLowerCase().trim();

    return students.filter((student) => {
      const matchesSearch =
        !search ||
        String(student.name || "")
          .toLowerCase()
          .includes(search) ||
        String(student.fatherName || "")
          .toLowerCase()
          .includes(search) ||
        String(student.cnic || "")
          .toLowerCase()
          .includes(search) ||
        String(student.qualification || "")
          .toLowerCase()
          .includes(search) ||
        String(student.domicile || "")
          .toLowerCase()
          .includes(search) ||
        String(student.status || "")
          .toLowerCase()
          .includes(search) ||
        String(student.email || "")
          .toLowerCase()
          .includes(search) ||
        String(student.phone || "")
          .toLowerCase()
          .includes(search) ||
        String(student.parentPhone || "")
          .toLowerCase()
          .includes(search) ||
        String(student.course || "")
          .toLowerCase()
          .includes(search);

      const matchesCourse =
        !courseFilter ||
        String(student.course || "") === courseFilter;

      return matchesSearch && matchesCourse;
    });
  }, [students, searchTerm, courseFilter]);

  // ===================================================
  // STUDENT STATISTICS
  // ===================================================

  const maleCount = students.filter(
    (student) =>
      String(student.gender || "").toLowerCase() === "male"
  ).length;

  const femaleCount = students.filter(
    (student) =>
      String(student.gender || "").toLowerCase() === "female"
  ).length;

  const activeStudentsCount = students.filter(
    (student) =>
      String(student.status || "Active").toLowerCase() === "active"
  ).length;

  // ===================================================
  // SHOW MESSAGE
  // ===================================================

  const showMessage = (type, text) => {
    setMessage({ type, text });

    setTimeout(() => {
      setMessage({ type: "", text: "" });
    }, 3500);
  };

  // ===================================================
  // OPEN EDIT MODAL
  // ===================================================

  const openEditModal = (student) => {
    setEditingStudent(student);

    setEditForm({
      name: student.name || "",
      fatherName: student.fatherName || "",
      cnic: student.cnic || "",
      qualification: student.qualification || "",
      domicile: student.domicile || "",
      email: student.email || "",
      password: "",
      phone: student.phone || "",
      parentPhone: student.parentPhone || "",
      gender: student.gender || "",
      course: student.course || "",
      address: student.address || "",
      status: student.status || "Active",
      image: null,
    });

    setEditImagePreview(getImageUrl(student.image));

    setMessage({ type: "", text: "" });
  };

  // ===================================================
  // CLOSE EDIT MODAL
  // ===================================================

  const closeEditModal = () => {
    setEditingStudent(null);

    setEditForm({
      name: "",
      fatherName: "",
      cnic: "",
      qualification: "",
      domicile: "",
      email: "",
      password: "",
      phone: "",
      parentPhone: "",
      gender: "",
      course: "",
      address: "",
      status: "Active",
      image: null,
    });

    setEditImagePreview("");
  };

  // ===================================================
  // EDIT INPUT CHANGE
  // ===================================================

  const handleEditChange = (e) => {
    const { name, value, files } = e.target;

    if (name === "image") {
      const file = files?.[0];

      if (!file) return;

      const allowedTypes = [
        "image/jpeg",
        "image/jpg",
        "image/png",
        "image/webp",
      ];

      if (!allowedTypes.includes(file.type)) {
        showMessage(
          "error",
          "Only JPG, JPEG, PNG and WEBP images are allowed."
        );

        e.target.value = "";
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        showMessage(
          "error",
          "Image size must be less than 5MB."
        );

        e.target.value = "";
        return;
      }

      setEditForm((prev) => ({
        ...prev,
        image: file,
      }));

      setEditImagePreview(URL.createObjectURL(file));

      return;
    }

    setEditForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // ===================================================
  // UPDATE STUDENT
  // ===================================================

  const handleUpdateStudent = async (e) => {
    e.preventDefault();

    if (!editingStudent) return;

    if (!editForm.name.trim()) {
      showMessage("error", "Student name is required.");
      return;
    }

    if (editForm.password && editForm.password.length < 8) {
      showMessage(
        "error",
        "New password must be at least 8 characters long."
      );
      return;
    }

    try {
      setUpdating(true);

      const formData = new FormData();

      formData.append("name", editForm.name);
      formData.append("fatherName", editForm.fatherName);
      formData.append("cnic", editForm.cnic);
      formData.append("qualification", editForm.qualification);
      formData.append("domicile", editForm.domicile);
      formData.append("email", editForm.email);

      if (editForm.password.trim()) {
        formData.append("password", editForm.password);
      }

      formData.append("phone", editForm.phone);
      formData.append("parentPhone", editForm.parentPhone);
      formData.append("gender", editForm.gender);
      formData.append("course", editForm.course);
      formData.append("address", editForm.address);

      if (editForm.image) {
        formData.append("image", editForm.image);
      }

      const response = await api.put(
        `/students/${editingStudent.id}`,
        formData
      );

      if (response.data?.success) {
        closeEditModal();

        showMessage(
          "success",
          "Student updated successfully."
        );

        await fetchStudents();
      } else {
        showMessage(
          "error",
          response.data?.message || "Student update failed."
        );
      }
    } catch (error) {
      console.error("Update student error:", error);

      showMessage(
        "error",
        error.response?.data?.message ||
          "Something went wrong while updating student."
      );
    } finally {
      setUpdating(false);
    }
  };

  // ===================================================
  // TOGGLE STUDENT STATUS
  // ===================================================

  const handleToggleStatus = async (student) => {
    const nextStatus =
      student.status === "De-Active" ? "Active" : "De-Active";

    try {
      const response = await api.put(
        `/students/${student.id}`,
        { status: nextStatus }
      );

      if (!response.data?.success) {
        throw new Error(
          response.data?.message ||
            "Unable to change student status."
        );
      }

      setStudents((previous) =>
        previous.map((item) =>
          item.id === student.id
            ? {
                ...item,
                ...(response.data.student || {}),
                status: nextStatus,
              }
            : item
        )
      );

      showMessage(
        "success",
        `${student.name || "Student"} status changed to ${nextStatus}.`
      );
    } catch (error) {
      console.error("Toggle student status error:", error);

      showMessage(
        "error",
        error.response?.data?.message ||
          error.message ||
          "Unable to change student status."
      );
    }
  };

  // ===================================================
  // DELETE STUDENT
  // ===================================================

  const handleDeleteStudent = async (id) => {
    const confirmed = window.confirm(
      "Are you sure you want to delete this student?"
    );

    if (!confirmed) return;

    try {
      const response = await api.delete(`/students/${id}`);

      if (response.data?.success) {
        setStudents((previous) =>
          previous.filter((student) => student.id !== id)
        );

        showMessage(
          "success",
          "Student deleted successfully."
        );
      } else {
        showMessage(
          "error",
          response.data?.message || "Unable to delete student."
        );
      }
    } catch (error) {
      console.error("Delete student error:", error);

      showMessage(
        "error",
        error.response?.data?.message ||
          "Something went wrong while deleting student."
      );
    }
  };

  // ===================================================
  // RESET FILTERS
  // ===================================================

  const resetFilters = () => {
    setSearchTerm("");
    setCourseFilter("");
  };

  const hasFilters =
    searchTerm.trim() !== "" || courseFilter !== "";

  // ===================================================
  // JSX
  // ===================================================

  return (
    <AdminLayout title="Students">
      <div className="min-h-screen bg-[#F6F7F6] p-1 sm:p-3">
        {/* MESSAGE */}

        {message.text && (
          <div
            role="alert"
            className={`mb-5 flex items-center gap-3 rounded-2xl border px-4 py-3 text-sm font-medium shadow-sm ${
              message.type === "success"
                ? "border-green-200 bg-green-50 text-green-800"
                : "border-red-200 bg-red-50 text-red-700"
            }`}
          >
            <span className="text-lg">
              {message.type === "success" ? "✓" : "⚠"}
            </span>

            {message.text}
          </div>
        )}

        {/* PAGE HEADER */}

        <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <h3 className="text-2xl font-semibold tracking-tight text-[#171C19] sm:text-3xl">
              Student Management
            </h3>

            <p className="mt-2 text-sm text-[#849087]">
              View, search, edit and manage your students with ease.
            </p>
          </div>

          <button
            type="button"
            onClick={() => navigate("/students/add")}
            className={`flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-semibold shadow-sm transition duration-300 hover:-translate-y-0.5 hover:shadow-lg ${GREEN_BUTTON}`}
          >
            <span className="text-lg">＋</span>
            Add New Student
          </button>
        </div>

        {/* =================================================
            STATISTICS CARDS
            ALL FOUR CARDS TURN GREEN ON HOVER
        ================================================= */}

        <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard
            title="Total Students"
            value={students.length}
            subtitle="All registered students"
            icon="♙"
          />

          <StatCard
            title="Male Students"
            value={maleCount}
            subtitle="Registered male students"
            icon="♂"
          />

          <StatCard
            title="Female Students"
            value={femaleCount}
            subtitle="Registered female students"
            icon="♀"
          />

          <StatCard
            title="Active Students"
            value={activeStudentsCount}
            subtitle="Currently active students"
            icon="✓"
          />
        </div>

        {/* ALL STUDENTS */}

        <div className="overflow-hidden rounded-[22px] border border-[#E8ECE9] bg-white shadow-sm">
          {/* CARD HEADER */}

          <div className="border-b border-[#EDF0ED] p-4 sm:p-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h3 className="text-lg font-semibold text-[#202721]">
                  All Students
                </h3>

                <p className="mt-1 text-sm text-[#89928B]">
                  Showing{" "}
                  <span className="font-semibold text-[#176B49]">
                    {filteredStudents.length}
                  </span>{" "}
                  of{" "}
                  <span className="font-semibold text-gray-700">
                    {students.length}
                  </span>{" "}
                  students
                </p>
              </div>

              {/* FILTERS */}

              <div className="flex flex-col gap-3 sm:flex-row">
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                    ⌕
                  </span>

                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search student..."
                    className={`${INPUT_CLASS} pl-10 sm:w-64`}
                  />
                </div>

                <select
                  value={courseFilter}
                  onChange={(e) => setCourseFilter(e.target.value)}
                  className={`${INPUT_CLASS} sm:w-auto`}
                >
                  <option value="">All Courses</option>

                  {courseOptions.map((course) => (
                    <option key={course} value={course}>
                      {course}
                    </option>
                  ))}
                </select>

                {hasFilters && (
                  <button
                    type="button"
                    onClick={resetFilters}
                    className="rounded-xl border border-gray-200 px-4 py-2.5 text-sm font-medium text-gray-600 transition hover:border-[#207A52] hover:bg-green-50 hover:text-[#176B49]"
                  >
                    Reset
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* TABLE */}

          <div className="overflow-x-auto">
            {loading ? (
              <div className="flex min-h-[320px] items-center justify-center">
                <div className="text-center">
                  <div className="mx-auto mb-3 h-10 w-10 animate-spin rounded-full border-4 border-green-100 border-t-[#176B49]" />

                  <p className="text-sm text-gray-500">
                    Loading students...
                  </p>
                </div>
              </div>
            ) : filteredStudents.length === 0 ? (
              <div className="flex min-h-[350px] flex-col items-center justify-center px-5 text-center">
                <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-green-50 text-4xl">
                  ♙
                </div>

                <h3 className="text-lg font-semibold text-gray-800">
                  No Students Found
                </h3>

                <p className="mt-2 max-w-md text-sm text-gray-500">
                  {hasFilters
                    ? "No student matches your current search or course filter."
                    : "There are no students registered yet."}
                </p>

                {hasFilters ? (
                  <button
                    type="button"
                    onClick={resetFilters}
                    className={`mt-4 rounded-full px-5 py-2.5 text-sm font-semibold transition ${GREEN_BUTTON}`}
                  >
                    Clear Filters
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => navigate("/students/add")}
                    className={`mt-4 rounded-full px-5 py-2.5 text-sm font-semibold transition ${GREEN_BUTTON}`}
                  >
                    Add First Student
                  </button>
                )}
              </div>
            ) : (
              <table className="w-full min-w-[1750px]">
                <thead>
                  <tr className="border-b border-gray-200 bg-[#F7F9F7]">
                    {[
                      "#",
                      "Student",
                      "Father Name",
                      "CNIC",
                      "Qualification",
                      "Domicile",
                      "Phone",
                      "Parent's Phone",
                      "Gender",
                      "Course",
                      "Address",
                      "Status",
                      "Actions",
                    ].map((heading) => (
                      <th
                        key={heading}
                        className="px-5 py-4 text-left text-xs font-semibold uppercase tracking-wide text-[#879188]"
                      >
                        {heading}
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody className="divide-y divide-gray-100">
                  {filteredStudents.map((student, index) => (
                    <tr
                      key={student.id}
                      className="group transition-colors duration-200 hover:bg-[#F0F8F3]"
                    >
                      {/* NUMBER */}

                      <td className="px-5 py-4 text-sm text-gray-500">
                        {index + 1}
                      </td>

                      {/* STUDENT */}

                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          {student.image ? (
                            <img
                              src={getImageUrl(student.image)}
                              alt={student.name || "Student"}
                              className="h-11 w-11 shrink-0 rounded-full border border-gray-200 object-cover"
                              onError={(e) => {
                                e.currentTarget.style.display = "none";
                                e.currentTarget.nextElementSibling?.classList.remove(
                                  "hidden"
                                );
                              }}
                            />
                          ) : null}

                          <div
                            className={`${
                              student.image ? "hidden" : ""
                            } flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#176B49] text-sm font-bold text-white`}
                          >
                            {getInitials(student.name)}
                          </div>

                          <div className="min-w-0">
                            <p className="truncate font-semibold text-gray-800 group-hover:text-[#176B49]">
                              {student.name || "Unnamed Student"}
                            </p>

                            <p className="mt-0.5 max-w-[220px] truncate text-xs text-gray-500">
                              {student.email || "No email"}
                            </p>
                          </div>
                        </div>
                      </td>

                      <td className="px-5 py-4 text-sm text-gray-600">
                        {student.fatherName || "-"}
                      </td>

                      <td className="px-5 py-4 text-sm text-gray-600">
                        {student.cnic || "-"}
                      </td>

                      <td className="px-5 py-4 text-sm text-gray-600">
                        {student.qualification || "-"}
                      </td>

                      <td className="px-5 py-4 text-sm text-gray-600">
                        {student.domicile || "-"}
                      </td>

                      <td className="px-5 py-4 text-sm text-gray-600">
                        {student.phone || "-"}
                      </td>

                      <td className="px-5 py-4 text-sm text-gray-600">
                        {student.parentPhone || "-"}
                      </td>

                      {/* GENDER */}

                      <td className="px-5 py-4">
                        {student.gender ? (
                          <span
                            className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${
                              String(student.gender).toLowerCase() === "male"
                                ? "bg-green-50 text-[#176B49]"
                                : "bg-pink-50 text-pink-700"
                            }`}
                          >
                            {student.gender}
                          </span>
                        ) : (
                          <span className="text-sm text-gray-400">-</span>
                        )}
                      </td>

                      {/* COURSE */}

                      <td className="px-5 py-4">
                        {student.course ? (
                          <span className="inline-flex max-w-[180px] truncate rounded-lg bg-green-50 px-3 py-1.5 text-xs font-semibold text-[#176B49]">
                            {student.course}
                          </span>
                        ) : (
                          <span className="text-sm text-gray-400">-</span>
                        )}
                      </td>

                      {/* ADDRESS */}

                      <td className="max-w-[220px] px-5 py-4">
                        <p
                          className="truncate text-sm text-gray-600"
                          title={student.address || ""}
                        >
                          {student.address || "-"}
                        </p>
                      </td>

                      {/* STATUS */}

                      <td className="px-5 py-4 text-center">
                        <div className="flex flex-col items-center gap-2">
                          <span
                            className={`inline-flex rounded-full px-3 py-1 text-xs font-bold ${
                              (student.status || "Active") === "Active"
                                ? "bg-green-100 text-green-700"
                                : "bg-red-100 text-red-700"
                            }`}
                          >
                            {student.status || "Active"}
                          </span>

                          <button
                            type="button"
                            onClick={() => handleToggleStatus(student)}
                            title={
                              student.status === "De-Active"
                                ? "Activate student"
                                : "Deactivate student"
                            }
                            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                              student.status === "De-Active"
                                ? "bg-green-50 text-green-700 hover:bg-green-100"
                                : "bg-red-50 text-red-700 hover:bg-red-100"
                            }`}
                          >
                            {student.status === "De-Active"
                              ? "Set Active"
                              : "Set De-Active"}
                          </button>
                        </div>
                      </td>

                      {/* ACTIONS */}

                      <td className="px-5 py-4">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={() => openEditModal(student)}
                            title="Edit Student"
                            className="flex h-9 w-9 items-center justify-center rounded-lg bg-green-50 text-[#176B49] transition hover:bg-[#176B49] hover:text-white"
                          >
                            ✏️
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeleteStudent(student.id)}
                            title="Delete Student"
                            className="flex h-9 w-9 items-center justify-center rounded-lg bg-red-50 text-red-600 transition hover:bg-red-600 hover:text-white"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* TABLE FOOTER */}

          {!loading && filteredStudents.length > 0 && (
            <div className="border-t border-gray-100 px-5 py-4 text-xs text-gray-500">
              Displaying {filteredStudents.length} student
              {filteredStudents.length !== 1 ? "s" : ""}
            </div>
          )}
        </div>
      </div>

      {/* =================================================
          EDIT STUDENT MODAL
      ================================================= */}

      {editingStudent && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
          <div className="max-h-[95vh] w-full max-w-4xl overflow-y-auto rounded-3xl bg-white shadow-2xl">
            {/* MODAL HEADER */}

            <div className="flex items-center justify-between bg-gradient-to-r from-[#104A32] to-[#26865B] px-5 py-4 text-white sm:px-6">
              <div>
                <h3 className="text-lg font-semibold">Edit Student</h3>
                <p className="mt-1 text-xs text-green-100">
                  Update student information
                </p>
              </div>

              <button
                type="button"
                onClick={closeEditModal}
                disabled={updating}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-xl transition hover:bg-white/20 disabled:opacity-50"
              >
                ×
              </button>
            </div>

            {/* FORM */}

            <form onSubmit={handleUpdateStudent} className="p-5 sm:p-6">
              <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                {/* NAME */}

                <FormField label="Student Name *">
                  <input
                    type="text"
                    name="name"
                    value={editForm.name}
                    onChange={handleEditChange}
                    placeholder="Enter student name"
                    required
                    className={INPUT_CLASS}
                  />
                </FormField>

                {/* FATHER */}

                <FormField label="Father Name">
                  <input
                    type="text"
                    name="fatherName"
                    value={editForm.fatherName}
                    onChange={handleEditChange}
                    placeholder="Enter father name"
                    className={INPUT_CLASS}
                  />
                </FormField>

                {/* CNIC */}

                <FormField label="CNIC Number">
                  <input
                    type="text"
                    name="cnic"
                    value={editForm.cnic}
                    onChange={handleEditChange}
                    maxLength={15}
                    placeholder="e.g. 42101-1234567-1"
                    className={INPUT_CLASS}
                  />
                </FormField>

                {/* QUALIFICATION */}

                <FormField label="Qualification">
                  <input
                    type="text"
                    name="qualification"
                    value={editForm.qualification}
                    onChange={handleEditChange}
                    placeholder="e.g. Matric, Intermediate"
                    className={INPUT_CLASS}
                  />
                </FormField>

                {/* DOMICILE */}

                <FormField label="Domicile">
                  <input
                    type="text"
                    name="domicile"
                    value={editForm.domicile}
                    onChange={handleEditChange}
                    placeholder="e.g. Hyderabad, Sindh"
                    className={INPUT_CLASS}
                  />
                </FormField>

                {/* EMAIL */}

                <FormField label="Email">
                  <input
                    type="email"
                    name="email"
                    value={editForm.email}
                    onChange={handleEditChange}
                    placeholder="Enter email"
                    className={INPUT_CLASS}
                  />
                </FormField>

                {/* PASSWORD */}

                <FormField label="New Password (optional)">
                  <input
                    type="password"
                    name="password"
                    value={editForm.password}
                    onChange={handleEditChange}
                    placeholder="Leave blank to keep current password"
                    autoComplete="new-password"
                    minLength={8}
                    className={INPUT_CLASS}
                  />

                  <p className="mt-1 text-xs text-gray-500">
                    Enter at least 8 characters only if you want to change it.
                  </p>
                </FormField>

                {/* PHONE */}

                <FormField label="Phone">
                  <input
                    type="text"
                    name="phone"
                    value={editForm.phone}
                    onChange={handleEditChange}
                    placeholder="Enter phone number"
                    className={INPUT_CLASS}
                  />
                </FormField>

                {/* PARENT PHONE */}

                <FormField label="Parent's Phone Number">
                  <input
                    type="tel"
                    name="parentPhone"
                    value={editForm.parentPhone}
                    onChange={handleEditChange}
                    placeholder="Enter parent's phone number"
                    className={INPUT_CLASS}
                  />
                </FormField>

                {/* GENDER */}

                <FormField label="Gender">
                  <select
                    name="gender"
                    value={editForm.gender}
                    onChange={handleEditChange}
                    className={`${INPUT_CLASS} bg-white`}
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </FormField>

                {/* COURSE */}

                <FormField label="Course">
                  <input
                    type="text"
                    name="course"
                    value={editForm.course}
                    onChange={handleEditChange}
                    placeholder="Enter course"
                    className={INPUT_CLASS}
                  />
                </FormField>

                {/* STATUS */}

                <FormField label="Current Student Status">
                  <div className="flex min-h-[46px] items-center rounded-xl border border-gray-200 bg-gray-50 px-4 py-3">
                    <span
                      className={`inline-flex rounded-full px-3 py-1.5 text-xs font-bold ${
                        editForm.status === "Active"
                          ? "bg-green-100 text-green-700"
                          : "bg-red-100 text-red-700"
                      }`}
                    >
                      {editForm.status === "Active"
                        ? "Active"
                        : "De-Active"}
                    </span>
                  </div>

                  <p className="mt-2 text-xs text-gray-500">
                    Change status using the status button in the Students list.
                  </p>
                </FormField>

                {/* ADDRESS */}

                <div className="md:col-span-2">
                  <FormField label="Address">
                    <textarea
                      name="address"
                      value={editForm.address}
                      onChange={handleEditChange}
                      rows="3"
                      placeholder="Enter student address"
                      className={`${INPUT_CLASS} resize-none`}
                    />
                  </FormField>
                </div>

                {/* IMAGE */}

                <div className="md:col-span-2">
                  <FormField label="Student Image">
                    <div className="flex flex-col gap-4 rounded-2xl border border-dashed border-green-200 bg-[#F7FAF7] p-4 sm:flex-row sm:items-center">
                      {editImagePreview ? (
                        <img
                          src={editImagePreview}
                          alt="Student Preview"
                          className="h-24 w-24 rounded-2xl border border-gray-200 object-cover"
                          onError={(e) => {
                            e.currentTarget.style.display = "none";
                          }}
                        />
                      ) : (
                        <div className="flex h-24 w-24 items-center justify-center rounded-2xl bg-green-100 text-3xl text-[#176B49]">
                          ♙
                        </div>
                      )}

                      <div className="flex-1">
                        <input
                          type="file"
                          name="image"
                          accept="image/jpeg,image/jpg,image/png,image/webp"
                          onChange={handleEditChange}
                          className="w-full text-sm text-gray-600 file:mr-4 file:rounded-xl file:border-0 file:bg-[#176B49] file:px-4 file:py-2.5 file:text-sm file:font-semibold file:text-white file:transition hover:file:bg-[#10583A]"
                        />

                        <p className="mt-2 text-xs text-gray-500">
                          JPG, JPEG, PNG or WEBP. Maximum size: 5MB.
                        </p>
                      </div>
                    </div>
                  </FormField>
                </div>
              </div>

              {/* BUTTONS */}

              <div className="mt-6 flex flex-col-reverse gap-3 border-t border-gray-100 pt-5 sm:flex-row sm:justify-end">
                <button
                  type="button"
                  onClick={closeEditModal}
                  disabled={updating}
                  className="rounded-full border border-gray-200 px-6 py-3 text-sm font-semibold text-gray-600 transition hover:bg-gray-50 disabled:opacity-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={updating}
                  className={`rounded-full px-6 py-3 text-sm font-semibold shadow-sm transition hover:shadow-lg disabled:cursor-not-allowed disabled:opacity-60 ${GREEN_BUTTON}`}
                >
                  {updating ? "Updating..." : "Save Changes"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminLayout>
  );
};

// =====================================================
// STATISTICS CARD — GREEN HOVER EFFECT
// =====================================================

function StatCard({ title, value, subtitle, icon }) {
  return (
    <div className="group relative overflow-hidden rounded-[22px] border border-[#E7ECE8] bg-white p-5 shadow-sm transition-all duration-300 ease-out hover:-translate-y-1 hover:border-[#207A52] hover:bg-gradient-to-br hover:from-[#104A32] hover:to-[#26865B] hover:shadow-xl hover:shadow-green-900/15">
      <div className="relative z-10 flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-[#7E8981] transition-colors duration-300 group-hover:text-green-100">
            {title}
          </p>

          <h4 className="mt-3 text-4xl font-semibold tracking-tight text-[#171C19] transition-colors duration-300 group-hover:text-white">
            {value}
          </h4>

          <p className="mt-3 text-xs leading-5 text-[#849087] transition-colors duration-300 group-hover:text-green-100">
            {subtitle}
          </p>
        </div>

        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#EDF7F0] text-xl font-semibold text-[#176B49] transition-all duration-300 group-hover:bg-white/15 group-hover:text-white">
          {icon}
        </div>
      </div>

      <div className="pointer-events-none absolute -bottom-10 -right-8 h-28 w-28 rounded-full bg-white/0 transition-all duration-300 group-hover:bg-white/10" />
    </div>
  );
}

// =====================================================
// FORM FIELD
// =====================================================

function FormField({ label, children }) {
  return (
    <div className="min-w-0">
      <label className="mb-2 block text-sm font-semibold text-gray-700">
        {label}
      </label>

      {children}
    </div>
  );
}

export default Students;
