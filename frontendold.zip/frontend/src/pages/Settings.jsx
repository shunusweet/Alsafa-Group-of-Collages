import { useState } from "react";
import AdminLayout from "../components/AdminLayout";

const Settings = () => {
  // ==========================================
  // USER DATA
  // ==========================================

  const savedUser = JSON.parse(
    localStorage.getItem("user") || "null"
  );

  // ==========================================
  // STATES
  // ==========================================

  const [profile, setProfile] = useState({
    name: savedUser?.name || "",
    email: savedUser?.email || "",
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [message, setMessage] = useState({
    type: "",
    text: "",
  });

  // ==========================================
  // PROFILE CHANGE
  // ==========================================

  const handleProfileChange = (e) => {
    const { name, value } = e.target;

    setProfile((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  // ==========================================
  // PASSWORD CHANGE
  // ==========================================

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;

    setPasswordData((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  // ==========================================
  // SAVE PROFILE
  // ==========================================

  const handleSaveProfile = (e) => {
    e.preventDefault();

    const updatedUser = {
      ...savedUser,
      name: profile.name,
      email: profile.email,
    };

    localStorage.setItem(
      "user",
      JSON.stringify(updatedUser)
    );

    setMessage({
      type: "success",
      text: "Profile updated successfully.",
    });

    setTimeout(() => {
      setMessage({
        type: "",
        text: "",
      });
    }, 3000);
  };

  // ==========================================
  // CHANGE PASSWORD
  // ==========================================

  const handleChangePassword = (e) => {
    e.preventDefault();

    if (
      !passwordData.currentPassword ||
      !passwordData.newPassword ||
      !passwordData.confirmPassword
    ) {
      setMessage({
        type: "error",
        text: "Please fill all password fields.",
      });

      return;
    }

    if (passwordData.newPassword.length < 6) {
      setMessage({
        type: "error",
        text: "New password must be at least 6 characters.",
      });

      return;
    }

    if (
      passwordData.newPassword !==
      passwordData.confirmPassword
    ) {
      setMessage({
        type: "error",
        text: "New password and confirm password do not match.",
      });

      return;
    }

    setMessage({
      type: "success",
      text:
        "Password validation successful. Connect this form to your backend password API.",
    });

    setPasswordData({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    });

    setTimeout(() => {
      setMessage({
        type: "",
        text: "",
      });
    }, 4000);
  };

  // ==========================================
  // RENDER
  // ==========================================

  return (
    <AdminLayout title="Settings">
      <div className="min-h-screen rounded-[28px] bg-[#f6f7f5] p-4 md:p-6">

        {/* ==========================================
            PAGE HEADER
        ========================================== */}

        <div className="mb-6 flex flex-col justify-between gap-4 rounded-[24px] bg-white p-5 shadow-sm md:flex-row md:items-center md:p-7">

          <div className="flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#0b5d3b] text-2xl text-white shadow-sm">
              ⚙️
            </div>

            <div>
              <h1 className="text-2xl font-bold tracking-tight text-[#17211d] md:text-3xl">
                Settings
              </h1>

              <p className="mt-1 text-sm text-[#84908a]">
                Manage your administrator account and system preferences.
              </p>
            </div>
          </div>

          <div className="rounded-full border border-[#dfe6e1] bg-[#f8faf8] px-4 py-2 text-sm font-medium text-[#35604c]">
            Administrator Panel
          </div>

        </div>

        {/* ==========================================
            MESSAGE
        ========================================== */}

        {message.text && (
          <div
            className={`mb-6 flex items-center gap-3 rounded-2xl border px-5 py-4 text-sm font-medium shadow-sm ${
              message.type === "success"
                ? "border-green-100 bg-green-50 text-[#167044]"
                : "border-red-100 bg-red-50 text-red-600"
            }`}
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-white">
              {message.type === "success" ? "✓" : "!"}
            </div>

            <span>{message.text}</span>
          </div>
        )}

        {/* ==========================================
            SETTINGS GRID
        ========================================== */}

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">

          {/* ==========================================
              PROFILE SETTINGS
          ========================================== */}

          <div className="overflow-hidden rounded-[24px] border border-white bg-white shadow-sm">

            <div className="flex items-center justify-between border-b border-[#edf1ee] px-6 py-5">

              <div className="flex items-center gap-3">

                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#eaf4ee] text-xl">
                  👤
                </div>

                <div>
                  <h2 className="text-lg font-bold text-[#17211d]">
                    Profile Settings
                  </h2>

                  <p className="mt-0.5 text-xs text-[#8a9690]">
                    Update your account information
                  </p>
                </div>

              </div>

              <div className="flex h-9 w-9 items-center justify-center rounded-full border border-[#d8e2dc] text-[#28543e]">
                ↗
              </div>

            </div>

            <form
              onSubmit={handleSaveProfile}
              className="p-6"
            >

              {/* NAME */}

              <div className="mb-5">

                <label className="mb-2 block text-sm font-semibold text-[#35423b]">
                  Full Name
                </label>

                <input
                  type="text"
                  name="name"
                  value={profile.name}
                  onChange={handleProfileChange}
                  placeholder="Enter your name"
                  className="w-full rounded-2xl border border-[#dfe6e1] bg-[#fbfcfb] px-4 py-3.5 text-sm text-[#1d2822] outline-none transition focus:border-[#0b5d3b] focus:ring-4 focus:ring-[#0b5d3b]/10"
                />

              </div>

              {/* EMAIL */}

              <div className="mb-6">

                <label className="mb-2 block text-sm font-semibold text-[#35423b]">
                  Email Address
                </label>

                <input
                  type="email"
                  name="email"
                  value={profile.email}
                  onChange={handleProfileChange}
                  placeholder="Enter your email"
                  className="w-full rounded-2xl border border-[#dfe6e1] bg-[#fbfcfb] px-4 py-3.5 text-sm text-[#1d2822] outline-none transition focus:border-[#0b5d3b] focus:ring-4 focus:ring-[#0b5d3b]/10"
                />

              </div>

              <button
                type="submit"
                className="flex w-full items-center justify-center gap-2 rounded-full bg-[#0b5d3b] px-5 py-3.5 text-sm font-semibold text-white transition hover:bg-[#08482e] active:scale-[0.99]"
              >
                <span>💾</span>
                Save Profile
              </button>

            </form>

          </div>

          {/* ==========================================
              PASSWORD SETTINGS
          ========================================== */}

          <div className="overflow-hidden rounded-[24px] border border-white bg-white shadow-sm">

            <div className="flex items-center justify-between border-b border-[#edf1ee] px-6 py-5">

              <div className="flex items-center gap-3">

                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#eaf4ee] text-xl">
                  🔐
                </div>

                <div>
                  <h2 className="text-lg font-bold text-[#17211d]">
                    Security
                  </h2>

                  <p className="mt-0.5 text-xs text-[#8a9690]">
                    Change and protect your password
                  </p>
                </div>

              </div>

              <div className="flex h-9 w-9 items-center justify-center rounded-full border border-[#d8e2dc] text-[#28543e]">
                ↗
              </div>

            </div>

            <form
              onSubmit={handleChangePassword}
              className="p-6"
            >

              {/* CURRENT PASSWORD */}

              <div className="mb-5">

                <label className="mb-2 block text-sm font-semibold text-[#35423b]">
                  Current Password
                </label>

                <input
                  type="password"
                  name="currentPassword"
                  value={passwordData.currentPassword}
                  onChange={handlePasswordChange}
                  placeholder="Enter current password"
                  className="w-full rounded-2xl border border-[#dfe6e1] bg-[#fbfcfb] px-4 py-3.5 text-sm text-[#1d2822] outline-none transition focus:border-[#0b5d3b] focus:ring-4 focus:ring-[#0b5d3b]/10"
                />

              </div>

              {/* NEW PASSWORD */}

              <div className="mb-5">

                <label className="mb-2 block text-sm font-semibold text-[#35423b]">
                  New Password
                </label>

                <input
                  type="password"
                  name="newPassword"
                  value={passwordData.newPassword}
                  onChange={handlePasswordChange}
                  placeholder="Enter new password"
                  className="w-full rounded-2xl border border-[#dfe6e1] bg-[#fbfcfb] px-4 py-3.5 text-sm text-[#1d2822] outline-none transition focus:border-[#0b5d3b] focus:ring-4 focus:ring-[#0b5d3b]/10"
                />

              </div>

              {/* CONFIRM PASSWORD */}

              <div className="mb-6">

                <label className="mb-2 block text-sm font-semibold text-[#35423b]">
                  Confirm New Password
                </label>

                <input
                  type="password"
                  name="confirmPassword"
                  value={passwordData.confirmPassword}
                  onChange={handlePasswordChange}
                  placeholder="Confirm new password"
                  className="w-full rounded-2xl border border-[#dfe6e1] bg-[#fbfcfb] px-4 py-3.5 text-sm text-[#1d2822] outline-none transition focus:border-[#0b5d3b] focus:ring-4 focus:ring-[#0b5d3b]/10"
                />

              </div>

              <button
                type="submit"
                className="flex w-full items-center justify-center gap-2 rounded-full bg-[#0b5d3b] px-5 py-3.5 text-sm font-semibold text-white transition hover:bg-[#08482e] active:scale-[0.99]"
              >
                <span>🔐</span>
                Change Password
              </button>

            </form>

          </div>

        </div>

        {/* ==========================================
            SYSTEM INFORMATION
        ========================================== */}

        <div className="mt-6 overflow-hidden rounded-[24px] bg-white shadow-sm">

          <div className="flex items-center justify-between border-b border-[#edf1ee] px-6 py-5">

            <div className="flex items-center gap-3">

              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#eaf4ee] text-xl">
                ℹ️
              </div>

              <div>
                <h2 className="text-lg font-bold text-[#17211d]">
                  System Information
                </h2>

                <p className="mt-0.5 text-xs text-[#8a9690]">
                  Application and technology details
                </p>
              </div>

            </div>

            <div className="flex h-9 w-9 items-center justify-center rounded-full border border-[#d8e2dc] text-[#28543e]">
              ↗
            </div>

          </div>

          <div className="grid grid-cols-1 gap-4 p-6 sm:grid-cols-2 lg:grid-cols-4">

            <div className="rounded-2xl border border-[#edf1ee] bg-[#fafcfb] p-5 transition hover:-translate-y-0.5 hover:shadow-sm">
              <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-[#eaf4ee]">
                🎓
              </div>

              <p className="text-xs font-medium text-[#8a9690]">
                Application
              </p>

              <p className="mt-1 font-bold text-[#26342c]">
                Student Management System
              </p>
            </div>

            <div className="rounded-2xl border border-[#edf1ee] bg-[#fafcfb] p-5 transition hover:-translate-y-0.5 hover:shadow-sm">
              <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-[#eaf4ee]">
                ⚛️
              </div>

              <p className="text-xs font-medium text-[#8a9690]">
                Frontend
              </p>

              <p className="mt-1 font-bold text-[#26342c]">
                React
              </p>
            </div>

            <div className="rounded-2xl border border-[#edf1ee] bg-[#fafcfb] p-5 transition hover:-translate-y-0.5 hover:shadow-sm">
              <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-[#eaf4ee]">
                ⚙️
              </div>

              <p className="text-xs font-medium text-[#8a9690]">
                Backend
              </p>

              <p className="mt-1 font-bold text-[#26342c]">
                Node.js
              </p>
            </div>

            <div className="rounded-2xl border border-[#edf1ee] bg-[#fafcfb] p-5 transition hover:-translate-y-0.5 hover:shadow-sm">
              <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-[#eaf4ee]">
                🗄️
              </div>

              <p className="text-xs font-medium text-[#8a9690]">
                Database
              </p>

              <p className="mt-1 font-bold text-[#26342c]">
                MySQL
              </p>
            </div>

          </div>

        </div>

      </div>
    </AdminLayout>
  );
};

export default Settings;