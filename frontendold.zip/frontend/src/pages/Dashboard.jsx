import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import AdminLayout from "../components/AdminLayout";
import api from "../services/api";

// ==========================================
// DASHBOARD
// ==========================================

const Dashboard = () => {
  const navigate = useNavigate();

  const user = JSON.parse(
    localStorage.getItem("user") || "null"
  );

  // ==========================================
  // STATES
  // ==========================================

  const [stats, setStats] = useState({
    students: 0,
    activeStudents: 0,
    courses: 0,
    staff: 0,
    activeStaff: 0,
    feeAccounts: 0,
    loading: true,
  });

  // ==========================================
  // LOAD DASHBOARD DATA
  // ==========================================

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        const results = await Promise.allSettled([
          api.get("/students"),
          api.get("/courses"),
          api.get("/staff"),
          api.get("/fees"),
        ]);

        // ======================================
        // STUDENTS
        // ======================================

        const studentResponse = results[0];

        const students =
          studentResponse.status === "fulfilled"
            ? studentResponse.value.data?.students ||
              studentResponse.value.data?.data ||
              []
            : [];

        const activeStudents = students.filter(
          (student) =>
            String(student.status || "")
              .toLowerCase()
              .replace("-", "") === "active"
        ).length;

        // ======================================
        // COURSES
        // ======================================

        const courseResponse = results[1];

        const courses =
          courseResponse.status === "fulfilled"
            ? courseResponse.value.data?.courses || []
            : [];

        // ======================================
        // STAFF
        // ======================================

        const staffResponse = results[2];

        const staff =
          staffResponse.status === "fulfilled"
            ? staffResponse.value.data?.staff ||
              staffResponse.value.data?.data ||
              []
            : [];

        const activeStaff = staff.filter(
          (member) => {
            const status = String(
              member.status || "Active"
            )
              .toLowerCase()
              .replace("-", "");

            return status === "active";
          }
        ).length;

        // ======================================
        // FEES
        // ======================================

        const feeResponse = results[3];

        const fees =
          feeResponse.status === "fulfilled"
            ? feeResponse.value.data?.fees || []
            : [];

        setStats({
          students: students.length,
          activeStudents,
          courses: courses.length,
          staff: staff.length,
          activeStaff,
          feeAccounts: fees.length,
          loading: false,
        });
      } catch (error) {
        console.error(
          "Dashboard Load Error:",
          error
        );

        setStats((previous) => ({
          ...previous,
          loading: false,
        }));
      }
    };

    loadDashboardData();
  }, []);

  // ==========================================
  // NAVIGATION
  // ==========================================

  const handleNavigation = (path) => {
    navigate(path);
  };

  // ==========================================
  // CURRENT DATE
  // ==========================================

  const currentDate = new Date().toLocaleDateString(
    "en-PK",
    {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    }
  );

  // ==========================================
  // QUICK ACTIONS
  // ==========================================

  const quickActions = [
    {
      title: "Add Student",
      description: "Register a new student",
      icon: "👨‍🎓",
      path: "/students/add",
    },
    {
      title: "Student Records",
      description: "View and manage students",
      icon: "👥",
      path: "/students",
    },
    {
      title: "Add Course",
      description: "Create a new course",
      icon: "📚",
      path: "/courses/add",
    },
    {
      title: "Course Records",
      description: "Manage available courses",
      icon: "📖",
      path: "/courses",
    },
    {
      title: "Add Staff",
      description: "Register a staff member",
      icon: "👨‍💼",
      path: "/staff/add",
    },
    {
      title: "Staff Records",
      description: "View and manage staff",
      icon: "👥",
      path: "/staff",
    },
    {
      title: "Add Fee",
      description: "Record student payment",
      icon: "💰",
      path: "/fees/add",
    },
    {
      title: "Fee Records",
      description: "Track fees and balances",
      icon: "📊",
      path: "/fees",
    },
  ];

  // ==========================================
  // MANAGEMENT CARDS
  // ==========================================

  const managementCards = [
    {
      title: "Student Management",
      description:
        "Manage student registrations and academic records.",
      icon: "👨‍🎓",
      primary: "Add Student",
      secondary: "View Students",
      primaryPath: "/students/add",
      secondaryPath: "/students",
    },
    {
      title: "Course Management",
      description:
        "Create and manage available courses and programs.",
      icon: "📚",
      primary: "Add Course",
      secondary: "View Courses",
      primaryPath: "/courses/add",
      secondaryPath: "/courses",
    },
    {
      title: "Staff Management",
      description:
        "Manage staff information and institutional records.",
      icon: "👨‍💼",
      primary: "Add Staff",
      secondary: "View Staff",
      primaryPath: "/staff/add",
      secondaryPath: "/staff",
    },
    {
      title: "Fee Management",
      description:
        "Record payments and monitor student fee balances.",
      icon: "💰",
      primary: "Add Payment",
      secondary: "View Fees",
      primaryPath: "/fees/add",
      secondaryPath: "/fees",
    },
  ];

  // ==========================================
  // RENDER
  // ==========================================

  return (
    <AdminLayout title="Dashboard">
      <div className="space-y-6">

        {/* ======================================
            OFFICIAL WELCOME HEADER
        ====================================== */}

        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#176B4D] via-[#16704F] to-[#0F5132] p-6 text-white shadow-lg md:p-8">

          {/* DECORATION */}

          <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/5" />

          <div className="absolute -bottom-16 right-32 h-48 w-48 rounded-full bg-white/5" />

          <div className="relative z-10 flex flex-col justify-between gap-6 lg:flex-row lg:items-center">

            {/* LEFT */}

            <div className="flex items-center gap-4">

              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl border border-white/20 bg-white/15 text-3xl shadow-sm">
                🏛️
              </div>

              <div>

                <p className="mb-1 text-sm font-medium text-green-100">
                  Administration Dashboard
                </p>

                <h1 className="text-2xl font-bold md:text-3xl">
                  Welcome,{" "}
                  {user?.name || "Administrator"} 👋
                </h1>

                <p className="mt-2 max-w-2xl text-sm leading-6 text-green-100">
                  Manage students, courses, staff and fee
                  records from one central administration
                  panel.
                </p>

              </div>

            </div>

            {/* DATE */}

            <div className="rounded-xl border border-white/15 bg-white/10 px-5 py-4 backdrop-blur-sm">

              <p className="text-xs uppercase tracking-wider text-green-100">
                Today
              </p>

              <p className="mt-1 font-semibold text-white">
                {currentDate}
              </p>

              <div className="mt-2 flex items-center gap-2 text-xs text-green-100">
                <span className="h-2 w-2 rounded-full bg-green-300" />
                System Online
              </div>

            </div>

          </div>

        </div>

        {/* ======================================
            SECTION HEADER
        ====================================== */}

        <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-end">

          <div>

            <p className="text-sm font-semibold uppercase tracking-wider text-[#176B4D]">
              Overview
            </p>

            <h2 className="mt-1 text-2xl font-bold text-gray-800">
              Institution Overview
            </h2>

            <p className="mt-1 text-sm text-gray-500">
              Current statistics from your management system.
            </p>

          </div>

          <div className="flex items-center gap-2 text-sm text-gray-500">

            <span className="h-2 w-2 rounded-full bg-green-500" />

            Live System Data

          </div>

        </div>

        {/* ======================================
            STATISTICS
        ====================================== */}

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-5">

          {/* STUDENTS */}

          <div className="group rounded-2xl border border-green-100 bg-white p-5 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-md">

            <div className="flex items-start justify-between">

              <div>

                <p className="text-sm font-medium text-gray-500">
                  Total Students
                </p>

                <h3 className="mt-3 text-3xl font-bold text-gray-800">
                  {stats.loading
                    ? "..."
                    : stats.students}
                </h3>

                <p className="mt-3 text-xs font-medium text-green-700">
                  {stats.loading
                    ? "Loading..."
                    : `${stats.activeStudents} Active Students`}
                </p>

              </div>

              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-green-50 text-2xl transition group-hover:scale-110">
                👨‍🎓
              </div>

            </div>

            <div className="mt-5 h-1 w-full overflow-hidden rounded-full bg-green-50">

              <div className="h-full w-3/4 rounded-full bg-[#176B4D]" />

            </div>

          </div>

          {/* COURSES */}

          <div className="group rounded-2xl border border-green-100 bg-white p-5 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-md">

            <div className="flex items-start justify-between">

              <div>

                <p className="text-sm font-medium text-gray-500">
                  Total Courses
                </p>

                <h3 className="mt-3 text-3xl font-bold text-gray-800">
                  {stats.loading
                    ? "..."
                    : stats.courses}
                </h3>

                <p className="mt-3 text-xs font-medium text-green-700">
                  Available Programs
                </p>

              </div>

              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-green-50 text-2xl transition group-hover:scale-110">
                📚
              </div>

            </div>

            <div className="mt-5 h-1 w-full overflow-hidden rounded-full bg-green-50">

              <div className="h-full w-2/3 rounded-full bg-[#176B4D]" />

            </div>

          </div>

          {/* STAFF */}

          <div className="group rounded-2xl border border-green-100 bg-white p-5 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-md">

            <div className="flex items-start justify-between">

              <div>

                <p className="text-sm font-medium text-gray-500">
                  Total Staff
                </p>

                <h3 className="mt-3 text-3xl font-bold text-gray-800">
                  {stats.loading
                    ? "..."
                    : stats.staff}
                </h3>

                <p className="mt-3 text-xs font-medium text-green-700">
                  {stats.loading
                    ? "Loading..."
                    : `${stats.activeStaff} Active Staff`}
                </p>

              </div>

              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-green-50 text-2xl transition group-hover:scale-110">
                👨‍💼
              </div>

            </div>

            <div className="mt-5 h-1 w-full overflow-hidden rounded-full bg-green-50">

              <div className="h-full w-4/5 rounded-full bg-[#176B4D]" />

            </div>

          </div>

          {/* FEE ACCOUNTS */}

          <div className="group rounded-2xl border border-green-100 bg-white p-5 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-md">

            <div className="flex items-start justify-between">

              <div>

                <p className="text-sm font-medium text-gray-500">
                  Fee Accounts
                </p>

                <h3 className="mt-3 text-3xl font-bold text-gray-800">
                  {stats.loading
                    ? "..."
                    : stats.feeAccounts}
                </h3>

                <p className="mt-3 text-xs font-medium text-green-700">
                  Student Fee Records
                </p>

              </div>

              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-green-50 text-2xl transition group-hover:scale-110">
                💰
              </div>

            </div>

            <div className="mt-5 h-1 w-full overflow-hidden rounded-full bg-green-50">

              <div className="h-full w-3/5 rounded-full bg-[#176B4D]" />

            </div>

          </div>

          {/* SYSTEM STATUS */}

          <div className="group rounded-2xl border border-green-100 bg-gradient-to-br from-[#176B4D] to-[#0F5132] p-5 text-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-md">

            <div className="flex items-start justify-between">

              <div>

                <p className="text-sm font-medium text-green-100">
                  System Status
                </p>

                <h3 className="mt-3 text-2xl font-bold">
                  Active
                </h3>

                <p className="mt-3 text-xs text-green-100">
                  All services operational
                </p>

              </div>

              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15 text-2xl">
                ✓
              </div>

            </div>

            <div className="mt-5 flex items-center gap-2 text-xs text-green-100">

              <span className="h-2 w-2 animate-pulse rounded-full bg-green-300" />

              System Running Successfully

            </div>

          </div>

        </div>

        {/* ======================================
            QUICK ACTIONS HEADER
        ====================================== */}

        <div className="flex items-center justify-between">

          <div>

            <p className="text-sm font-semibold uppercase tracking-wider text-[#176B4D]">
              Quick Access
            </p>

            <h2 className="mt-1 text-2xl font-bold text-gray-800">
              Quick Actions
            </h2>

            <p className="mt-1 text-sm text-gray-500">
              Quickly access frequently used management sections.
            </p>

          </div>

          <div className="hidden h-px flex-1 bg-green-100 sm:ml-8 sm:block" />

        </div>

        {/* ======================================
            QUICK ACTION CARDS
        ====================================== */}

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">

          {quickActions.map((action) => (
            <button
              key={action.title}
              type="button"
              onClick={() =>
                handleNavigation(action.path)
              }
              className="group relative overflow-hidden rounded-2xl border border-green-100 bg-white p-5 text-left shadow-sm transition duration-300 hover:-translate-y-1 hover:border-[#176B4D] hover:shadow-md"
            >

              <div className="absolute right-0 top-0 h-20 w-20 rounded-bl-full bg-green-50 transition group-hover:bg-green-100" />

              <div className="relative z-10 flex items-center gap-4">

                <div className="flex h-13 w-13 min-h-[52px] min-w-[52px] items-center justify-center rounded-xl bg-[#176B4D] text-2xl text-white shadow-sm transition duration-300 group-hover:scale-110">

                  {action.icon}

                </div>

                <div className="min-w-0">

                  <h3 className="font-bold text-gray-800 transition group-hover:text-[#176B4D]">
                    {action.title}
                  </h3>

                  <p className="mt-1 text-xs leading-5 text-gray-500">
                    {action.description}
                  </p>

                </div>

              </div>

              <div className="relative z-10 mt-4 flex items-center text-xs font-semibold text-[#176B4D]">

                Open Section

                <span className="ml-2 transition-transform group-hover:translate-x-1">
                  →
                </span>

              </div>

            </button>
          ))}

        </div>

        {/* ======================================
            MANAGEMENT SECTION
        ====================================== */}

        <div className="pt-2">

          <div className="mb-5">

            <p className="text-sm font-semibold uppercase tracking-wider text-[#176B4D]">
              Administration
            </p>

            <h2 className="mt-1 text-2xl font-bold text-gray-800">
              Management Center
            </h2>

            <p className="mt-1 text-sm text-gray-500">
              Access complete management tools for your institution.
            </p>

          </div>

          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-4">

            {managementCards.map((card) => (
              <div
                key={card.title}
                className="overflow-hidden rounded-2xl border border-green-100 bg-white shadow-sm transition duration-300 hover:shadow-md"
              >

                {/* CARD HEADER */}

                <div className="bg-gradient-to-r from-[#176B4D] to-[#0F5132] p-5 text-white">

                  <div className="flex items-center gap-3">

                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/15 text-2xl">

                      {card.icon}

                    </div>

                    <div>

                      <h2 className="font-bold">
                        {card.title}
                      </h2>

                      <p className="mt-1 text-xs leading-5 text-green-100">
                        {card.description}
                      </p>

                    </div>

                  </div>

                </div>

                {/* CARD BODY */}

                <div className="space-y-3 p-5">

                  <button
                    type="button"
                    onClick={() =>
                      handleNavigation(
                        card.primaryPath
                      )
                    }
                    className="group flex w-full items-center justify-between rounded-xl bg-green-50 px-4 py-3 text-left transition hover:bg-[#176B4D]"
                  >

                    <div className="flex items-center gap-3">

                      <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#176B4D] font-bold text-white transition group-hover:bg-white group-hover:text-[#176B4D]">
                        +
                      </span>

                      <span className="text-sm font-semibold text-gray-700 group-hover:text-white">
                        {card.primary}
                      </span>

                    </div>

                    <span className="font-bold text-[#176B4D] group-hover:text-white">
                      →
                    </span>

                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      handleNavigation(
                        card.secondaryPath
                      )
                    }
                    className="group flex w-full items-center justify-between rounded-xl border border-gray-100 bg-white px-4 py-3 text-left transition hover:border-green-200 hover:bg-green-50"
                  >

                    <div className="flex items-center gap-3">

                      <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-green-100 text-sm font-bold text-[#176B4D]">
                        ☷
                      </span>

                      <span className="text-sm font-semibold text-gray-700">
                        {card.secondary}
                      </span>

                    </div>

                    <span className="font-bold text-[#176B4D]">
                      →
                    </span>

                  </button>

                </div>

              </div>
            ))}

          </div>

        </div>

        {/* ======================================
            FOOTER INFORMATION
        ====================================== */}

        <div className="rounded-2xl border border-green-100 bg-green-50 px-5 py-4">

          <div className="flex flex-col justify-between gap-3 text-sm md:flex-row md:items-center">

            <div className="flex items-center gap-3">

              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#176B4D] text-white">
                🏛️
              </div>

              <div>

                <p className="font-semibold text-gray-800">
                  Student Management System
                </p>

                <p className="text-xs text-gray-500">
                  Centralized administration and institutional management platform
                </p>

              </div>

            </div>

            <div className="flex items-center gap-2 text-xs font-medium text-[#176B4D]">

              <span className="h-2 w-2 animate-pulse rounded-full bg-green-500" />

              System Secure & Operational

            </div>

          </div>

        </div>

      </div>
    </AdminLayout>
  );
};

export default Dashboard;