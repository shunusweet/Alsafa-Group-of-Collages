
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AdminLayout from "../components/AdminLayout";
import api from "../services/api";

// ==========================================
// LOCAL DATE
// ==========================================

const getToday = () => {
  const now = new Date();

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
};

// ==========================================
// MAIN COMPONENT
// ==========================================

const AddStaffAttendance = () => {
  const navigate = useNavigate();

  const [staffList, setStaffList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const [formData, setFormData] = useState({
    staffId: "",
    date: getToday(),
    checkIn: "",
    checkOut: "",
    status: "Present",
    remarks: "",
  });

  // ==========================================
  // LOAD STAFF
  // ==========================================

  useEffect(() => {
    const loadStaff = async () => {
      setLoading(true);
      setError("");

      try {
        const response = await api.get("/staff");

        const data =
          response.data?.staff ||
          response.data?.staffs ||
          response.data?.data ||
          (Array.isArray(response.data)
            ? response.data
            : []);

        setStaffList(data);
      } catch (err) {
        console.error("Load Staff Error:", err);

        setError(
          err.response?.data?.message ||
          "Staff list load nahi hui. Backend API check karein."
        );
      } finally {
        setLoading(false);
      }
    };

    loadStaff();
  }, []);

  // ==========================================
  // INPUT CHANGE
  // ==========================================

  const handleChange = (event) => {
    const { name, value } = event.target;

    setFormData((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  // ==========================================
  // SELECTED STAFF
  // ==========================================

  const selectedStaff = staffList.find(
    (staff) =>
      String(staff.id ?? staff.staff_id) ===
      String(formData.staffId)
  );

  const getStaffName = (staff) =>
    staff.staffName ||
    staff.staff_name ||
    staff.name ||
    "Unnamed Staff";

  // ==========================================
  // SAVE ATTENDANCE
  // ==========================================

  const handleSubmit = async (event) => {
    event.preventDefault();

    setError("");
    setMessage("");

    if (!formData.staffId) {
      setError("Please select a staff member.");
      return;
    }

    if (
      formData.checkIn &&
      formData.checkOut &&
      formData.checkOut <= formData.checkIn
    ) {
      setError(
        "Check-out time must be later than check-in time."
      );
      return;
    }

    setSaving(true);

    try {
      const response = await api.post(
        "/staff-attendance",
        {
          staffId: Number(formData.staffId),
          date: formData.date,
          checkIn: formData.checkIn || null,
          checkOut: formData.checkOut || null,
          status: formData.status,
          remarks: formData.remarks.trim(),
        }
      );

      if (response.data?.success === false) {
        setError(
          response.data.message ||
          "Attendance save nahi hui."
        );
        return;
      }

      setMessage("Staff attendance successfully saved!");

      navigate("/staff-attendance");
    } catch (err) {
      console.error("Save Attendance Error:", err);

      setError(
        err.response?.data?.message ||
        "Attendance save nahi hui. Backend API route check karein."
      );
    } finally {
      setSaving(false);
    }
  };

  // ==========================================
  // RESET FORM
  // ==========================================

  const handleReset = () => {
    setFormData({
      staffId: "",
      date: getToday(),
      checkIn: "",
      checkOut: "",
      status: "Present",
      remarks: "",
    });

    setError("");
    setMessage("");
  };

  // ==========================================
  // STATUS COLOR
  // ==========================================

  const statusColors = {
    Present: "bg-green-100 text-green-700",
    Absent: "bg-red-100 text-red-700",
    Late: "bg-yellow-100 text-yellow-700",
    "Half Day": "bg-blue-100 text-blue-700",
    Leave: "bg-purple-100 text-purple-700",
  };

  // ==========================================
  // REUSABLE INPUT STYLE
  // ==========================================

  const inputStyle =
    "w-full rounded-xl border border-gray-200 bg-[#fafbf9] px-4 py-3.5 text-sm text-gray-800 outline-none transition-all focus:border-emerald-600 focus:bg-white focus:ring-4 focus:ring-emerald-50 disabled:cursor-not-allowed disabled:opacity-60";

  const labelStyle =
    "mb-2 block text-sm font-semibold text-gray-700";

  // ==========================================
  // UI
  // ==========================================

  return (
    <AdminLayout title="Add Staff Attendance">

      <div className="min-h-screen space-y-6 bg-[#f7f8f6] p-1">

        {/* ================================= */}
        {/* PAGE HEADER */}
        {/* ================================= */}

        <div className="flex flex-col justify-between gap-4 rounded-2xl bg-white p-5 shadow-sm md:flex-row md:items-center md:p-6">

          <div>
            <div className="mb-2 flex items-center gap-2 text-sm text-gray-400">
              <span>Dashboard</span>
              <span>/</span>
              <span>Staff Attendance</span>
              <span>/</span>
              <span className="font-medium text-emerald-700">
                Add Attendance
              </span>
            </div>

            <h1 className="text-2xl font-bold tracking-tight text-gray-900 md:text-3xl">
              Add Staff Attendance
            </h1>

            <p className="mt-2 text-sm text-gray-400">
              Manage and record daily staff attendance.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">

            <button
              type="button"
              onClick={() => navigate("/staff-attendance")}
              className="rounded-full border border-emerald-800 px-5 py-3 text-sm font-semibold text-emerald-900 transition hover:bg-emerald-50"
            >
              View Attendance
            </button>

            <button
              type="button"
              onClick={() => navigate(-1)}
              className="rounded-full bg-[#115b3d] px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-[#0b4930]"
            >
              ← Back
            </button>

          </div>
        </div>

        {/* ================================= */}
        {/* SUMMARY CARDS */}
        {/* ================================= */}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">

          {/* TOTAL STAFF */}

          <div className="rounded-2xl bg-gradient-to-br from-[#104e36] to-[#25835d] p-5 text-white shadow-sm">

            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-white/80">
                Total Staff Members
              </p>

              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/20 text-xl">
                ♙
              </div>
            </div>

            <h2 className="mt-4 text-4xl font-bold">
              {loading ? "..." : staffList.length}
            </h2>

            <p className="mt-2 text-xs text-white/70">
              Registered staff members
            </p>
          </div>

          {/* SELECTED STAFF */}

          <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">

            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-gray-500">
                Selected Staff
              </p>

              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-50 text-xl text-emerald-700">
                ✓
              </div>
            </div>

            <h2 className="mt-4 truncate text-2xl font-bold text-gray-900">
              {selectedStaff
                ? getStaffName(selectedStaff)
                : "Not Selected"}
            </h2>

            <p className="mt-2 text-xs text-gray-400">
              Current attendance member
            </p>
          </div>

          {/* ATTENDANCE STATUS */}

          <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm sm:col-span-2 xl:col-span-1">

            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-gray-500">
                Attendance Status
              </p>

              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-50 text-xl text-emerald-700">
                ◉
              </div>
            </div>

            <div className="mt-4">
              <span
                className={`rounded-full px-4 py-2 text-sm font-semibold ${
                  statusColors[formData.status]
                }`}
              >
                {formData.status}
              </span>
            </div>

            <p className="mt-3 text-xs text-gray-400">
              Selected attendance status
            </p>
          </div>

        </div>

        {/* ================================= */}
        {/* ERROR / SUCCESS */}
        {/* ================================= */}

        {error && (
          <div className="flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            <span className="text-lg">⚠</span>
            <p>{error}</p>
          </div>
        )}

        {message && (
          <div className="rounded-xl border border-green-200 bg-green-50 p-4 text-sm text-green-700">
            ✓ {message}
          </div>
        )}

        {/* ================================= */}
        {/* MAIN FORM */}
        {/* ================================= */}

        <form
          onSubmit={handleSubmit}
          className="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm"
        >

          {/* FORM HEADER */}

          <div className="flex flex-col justify-between gap-3 border-b border-gray-100 p-5 md:flex-row md:items-center md:p-6">

            <div>
              <h2 className="text-lg font-bold text-gray-900">
                Attendance Details
              </h2>

              <p className="mt-1 text-sm text-gray-400">
                Enter staff information and attendance timing.
              </p>
            </div>

            <div className="rounded-full bg-emerald-50 px-4 py-2 text-xs font-semibold text-emerald-800">
              Daily Attendance
            </div>

          </div>

          {/* FORM CONTENT */}

          <div className="space-y-7 p-5 md:p-7">

            {/* STAFF INFORMATION */}

            <div>

              <h3 className="mb-5 flex items-center gap-2 text-base font-bold text-gray-800">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-800">
                  ♙
                </span>
                Staff Information
              </h3>

              <div className="grid grid-cols-1 gap-5 md:grid-cols-2">

                {/* STAFF SELECT */}

                <div>
                  <label className={labelStyle}>
                    Select Staff Member *
                  </label>

                  <select
                    name="staffId"
                    value={formData.staffId}
                    onChange={handleChange}
                    required
                    disabled={loading || staffList.length === 0}
                    className={inputStyle}
                  >
                    <option value="">
                      {loading
                        ? "Loading staff..."
                        : staffList.length === 0
                        ? "No staff available"
                        : "Choose staff member"}
                    </option>

                    {staffList.map((staff) => (
                      <option
                        key={staff.id ?? staff.staff_id}
                        value={staff.id ?? staff.staff_id}
                      >
                        {getStaffName(staff)}
                        {staff.fatherName || staff.father_name
                          ? ` — ${staff.fatherName || staff.father_name}`
                          : ""}
                      </option>
                    ))}
                  </select>
                </div>

                {/* DATE */}

                <div>
                  <label className={labelStyle}>
                    Attendance Date *
                  </label>

                  <input
                    type="date"
                    name="date"
                    value={formData.date}
                    onChange={handleChange}
                    required
                    className={inputStyle}
                  />
                </div>

              </div>
            </div>

            {/* DIVIDER */}

            <div className="border-t border-gray-100" />

            {/* ATTENDANCE TIMING */}

            <div>

              <h3 className="mb-5 flex items-center gap-2 text-base font-bold text-gray-800">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-800">
                  ◷
                </span>
                Attendance Timing
              </h3>

              <div className="grid grid-cols-1 gap-5 md:grid-cols-2">

                {/* CHECK IN */}

                <div>
                  <label className={labelStyle}>
                    Check-in Time
                  </label>

                  <div className="relative">
                    <input
                      type="time"
                      name="checkIn"
                      value={formData.checkIn}
                      onChange={handleChange}
                      className={inputStyle}
                    />
                  </div>

                  <p className="mt-2 text-xs text-gray-400">
                    Staff arrival time
                  </p>
                </div>

                {/* CHECK OUT */}

                <div>
                  <label className={labelStyle}>
                    Check-out Time
                  </label>

                  <input
                    type="time"
                    name="checkOut"
                    value={formData.checkOut}
                    onChange={handleChange}
                    className={inputStyle}
                  />

                  <p className="mt-2 text-xs text-gray-400">
                    Staff departure time
                  </p>
                </div>

              </div>
            </div>

            {/* DIVIDER */}

            <div className="border-t border-gray-100" />

            {/* STATUS & REMARKS */}

            <div>

              <h3 className="mb-5 flex items-center gap-2 text-base font-bold text-gray-800">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-800">
                  ✓
                </span>
                Status & Remarks
              </h3>

              <div className="grid grid-cols-1 gap-5 md:grid-cols-2">

                {/* STATUS */}

                <div>
                  <label className={labelStyle}>
                    Attendance Status *
                  </label>

                  <select
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    required
                    className={inputStyle}
                  >
                    <option value="Present">Present</option>
                    <option value="Absent">Absent</option>
                    <option value="Late">Late</option>
                    <option value="Half Day">Half Day</option>
                    <option value="Leave">Leave</option>
                  </select>

                  <div className="mt-3">
                    <span
                      className={`rounded-full px-3 py-1.5 text-xs font-semibold ${
                        statusColors[formData.status]
                      }`}
                    >
                      {formData.status}
                    </span>
                  </div>
                </div>

                {/* REMARKS */}

                <div>
                  <label className={labelStyle}>
                    Remarks
                  </label>

                  <textarea
                    name="remarks"
                    value={formData.remarks}
                    onChange={handleChange}
                    rows="4"
                    placeholder="Enter additional attendance remarks..."
                    className={`${inputStyle} resize-none`}
                  />
                </div>

              </div>
            </div>

          </div>

          {/* ================================= */}
          {/* FORM FOOTER */}
          {/* ================================= */}

          <div className="flex flex-col-reverse justify-between gap-3 border-t border-gray-100 bg-[#fafbf9] p-5 sm:flex-row sm:items-center md:px-7">

            <button
              type="button"
              onClick={handleReset}
              disabled={saving}
              className="rounded-full border border-gray-300 bg-white px-7 py-3 text-sm font-semibold text-gray-600 transition hover:bg-gray-100 disabled:opacity-50"
            >
              ↻ Reset Form
            </button>

            <div className="flex flex-col gap-3 sm:flex-row">

              <button
                type="button"
                onClick={() => navigate("/staff-attendance")}
                className="rounded-full border border-emerald-800 px-6 py-3 text-sm font-semibold text-emerald-900 transition hover:bg-emerald-50"
              >
                View Attendance
              </button>

              <button
                type="submit"
                disabled={
                  saving ||
                  loading ||
                  staffList.length === 0
                }
                className="rounded-full bg-gradient-to-r from-[#104e36] to-[#23845d] px-8 py-3 text-sm font-semibold text-white shadow-md transition hover:shadow-lg disabled:cursor-not-allowed disabled:opacity-60"
              >
                {saving
                  ? "Saving Attendance..."
                  : "✓ Save Attendance"}
              </button>

            </div>
          </div>

        </form>

        {/* BOTTOM NOTE */}

        <div className="rounded-xl border border-emerald-100 bg-emerald-50/60 p-4">
          <p className="text-xs leading-6 text-emerald-900">
            <strong>Note:</strong> Please verify staff information,
            attendance date and check-in/check-out timings before
            saving the attendance record.
          </p>
        </div>

      </div>

    </AdminLayout>
  );
};

export default AddStaffAttendance;
