
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const Sidebar = ({
  sidebarOpen = false,
  setSidebarOpen = () => {},
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  const [studentsOpen, setStudentsOpen] = useState(false);
  const [studentAttendanceOpen, setStudentAttendanceOpen] =
    useState(false);
  const [coursesOpen, setCoursesOpen] = useState(false);
  const [staffOpen, setStaffOpen] = useState(false);
  const [staffAttendanceOpen, setStaffAttendanceOpen] =
    useState(false);
  const [feesOpen, setFeesOpen] = useState(false);

  useEffect(() => {
    const path = location.pathname;

    if (path.startsWith("/students")) setStudentsOpen(true);
    if (path.startsWith("/attendance")) {
      setStudentAttendanceOpen(true);
    }
    if (path.startsWith("/courses")) setCoursesOpen(true);
    if (path === "/staff" || path.startsWith("/staff/")) {
      setStaffOpen(true);
    }
    if (path.startsWith("/staff-attendance")) {
      setStaffAttendanceOpen(true);
    }
    if (path.startsWith("/fees")) setFeesOpen(true);
  }, [location.pathname]);

  const handleNavigation = (path) => {
    navigate(path);
    setSidebarOpen(false);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setSidebarOpen(false);
    navigate("/login", { replace: true });
  };

  const isActive = (path) => location.pathname === path;

  const isSectionActive = (prefix) =>
    location.pathname.startsWith(prefix);

  // Main menu: active and hover both green
  const mainMenuClass = (active = false) =>
    `group mb-1 flex w-full items-center justify-between
    rounded-xl px-3 py-2.5 text-left text-[13px]
    transition-all duration-200 ${
      active
        ? "bg-[#198754] font-semibold text-white shadow-sm"
        : "font-medium text-[#85918b] hover:bg-[#198754] hover:text-white"
    }`;

  // Dropdown items: active and hover both green
  const subMenuClass = (active = false) =>
    `flex w-full items-center gap-2 rounded-lg px-3 py-2
    text-left text-xs transition-all duration-200 ${
      active
        ? "bg-[#198754] font-semibold text-white"
        : "text-[#89948e] hover:bg-[#198754] hover:text-white"
    }`;

  const renderDropdown = ({
    label,
    icon,
    isOpen,
    setIsOpen,
    active,
    items,
  }) => (
    <div className="mb-1" key={label}>
      <button
        type="button"
        aria-expanded={isOpen}
        onClick={() => setIsOpen((current) => !current)}
        className={mainMenuClass(active)}
      >
        <span className="flex min-w-0 items-center gap-3">
          <span
            aria-hidden="true"
            className="flex w-4 shrink-0 items-center justify-center text-base"
          >
            {icon}
          </span>

          <span className="truncate">{label}</span>
        </span>

        <span
          aria-hidden="true"
          className={`text-[10px] transition-transform duration-200 ${
            isOpen ? "rotate-180" : ""
          }`}
        >
          ▼
        </span>
      </button>

      {isOpen && (
        <div className="ml-4 mt-1 space-y-1 border-l border-[#dce8df] pl-2">
          {items.map((item) => (
            <button
              key={item.path}
              type="button"
              onClick={() => handleNavigation(item.path)}
              className={subMenuClass(isActive(item.path))}
            >
              <span aria-hidden="true">{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <button
          type="button"
          aria-label="Close sidebar overlay"
          className="fixed inset-0 z-40 bg-black/40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={`fixed left-0 top-0 z-50 flex h-screen
        w-[230px] flex-col border-r border-[#edf0ed]
        bg-[#f8f9f8] px-3 pb-3 pt-4 text-[#26332c]
        shadow-sm transition-transform duration-300
        lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Logo */}
        <div className="flex h-[58px] shrink-0 items-center gap-2.5 px-3">
          <div
            className="flex h-9 w-9 items-center justify-center
            rounded-xl bg-[#e5f4eb] text-[#218453]"
            aria-hidden="true"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              className="h-7 w-7"
              stroke="currentColor"
              strokeWidth="2"
            >
              <circle cx="12" cy="12" r="9" />
              <circle cx="12" cy="12" r="4" />
              <path d="M12 3v5M17.5 6.5l-3 3" />
            </svg>
          </div>

          <div className="min-w-0 flex-1">
            <h1 className="text-[17px] font-semibold tracking-tight text-[#202923]">
              Student
              <span className="text-[#218453]">Hub</span>
            </h1>

            <p className="text-[10px] text-[#9aa39d]">
              Management System
            </p>
          </div>

          <button
            type="button"
            aria-label="Close sidebar"
            onClick={() => setSidebarOpen(false)}
            className="ml-auto rounded-lg p-1 text-lg text-[#8c9890] hover:bg-[#e9f0eb] lg:hidden"
          >
            ×
          </button>
        </div>

        {/* Navigation */}
        <nav
          className="mt-3 min-h-0 flex-1 overflow-y-auto
          overscroll-contain pr-1"
          aria-label="Admin navigation"
        >
          <p className="mb-3 mt-3 px-3 text-[10px] font-medium uppercase tracking-wider text-[#a1a8a3]">
            Menu
          </p>

          {/* Dashboard */}
          <button
            type="button"
            onClick={() => handleNavigation("/dashboard")}
            className={mainMenuClass(isActive("/dashboard"))}
          >
            <span className="flex items-center gap-3">
              <span aria-hidden="true" className="text-base">
                ▦
              </span>
              <span>Dashboard</span>
            </span>
          </button>

          {/* Students */}
          {renderDropdown({
            label: "Students",
            icon: "♙",
            isOpen: studentsOpen,
            setIsOpen: setStudentsOpen,
            active: isSectionActive("/students"),
            items: [
              {
                label: "Add Student",
                path: "/students/add",
                icon: "＋",
              },
              {
                label: "View Students",
                path: "/students",
                icon: "☷",
              },
            ],
          })}

          {/* Student Attendance */}
          {renderDropdown({
            label: "Student Attendance",
            icon: "▤",
            isOpen: studentAttendanceOpen,
            setIsOpen: setStudentAttendanceOpen,
            active: isSectionActive("/attendance"),
            items: [
              {
                label: "Add Attendance",
                path: "/attendance/add",
                icon: "＋",
              },
              {
                label: "View Attendance",
                path: "/attendance",
                icon: "☷",
              },
            ],
          })}

          {/* Courses */}
          {renderDropdown({
            label: "Courses",
            icon: "▣",
            isOpen: coursesOpen,
            setIsOpen: setCoursesOpen,
            active: isSectionActive("/courses"),
            items: [
              {
                label: "Add Course",
                path: "/courses/add",
                icon: "＋",
              },
              {
                label: "View Courses",
                path: "/courses",
                icon: "☷",
              },
            ],
          })}

          {/* Staff */}
          {renderDropdown({
            label: "Staff",
            icon: "♧",
            isOpen: staffOpen,
            setIsOpen: setStaffOpen,
            active:
              location.pathname === "/staff" ||
              location.pathname.startsWith("/staff/"),
            items: [
              {
                label: "Add Staff",
                path: "/staff/add",
                icon: "＋",
              },
              {
                label: "View Staff",
                path: "/staff",
                icon: "☷",
              },
            ],
          })}

          {/* Staff Attendance */}
          {renderDropdown({
            label: "Staff Attendance",
            icon: "◷",
            isOpen: staffAttendanceOpen,
            setIsOpen: setStaffAttendanceOpen,
            active: isSectionActive("/staff-attendance"),
            items: [
              {
                label: "Add Attendance",
                path: "/staff-attendance/add",
                icon: "＋",
              },
              {
                label: "View Attendance",
                path: "/staff-attendance",
                icon: "☷",
              },
            ],
          })}

          {/* Fees */}
          {renderDropdown({
            label: "Fees",
            icon: "＄",
            isOpen: feesOpen,
            setIsOpen: setFeesOpen,
            active: isSectionActive("/fees"),
            items: [
              {
                label: "Add Fee",
                path: "/fees/add",
                icon: "＋",
              },
              {
                label: "View Fees",
                path: "/fees",
                icon: "☷",
              },
            ],
          })}

          {/* General section */}
          <div className="mb-3 mt-7 px-3">
            <p className="text-[10px] font-medium uppercase tracking-wider text-[#a1a8a3]">
              General
            </p>
          </div>

          {/* Settings */}
          <button
            type="button"
            onClick={() => handleNavigation("/settings")}
            className={mainMenuClass(isActive("/settings"))}
          >
            <span className="flex items-center gap-3">
              <span aria-hidden="true" className="text-base">
                ⚙
              </span>
              <span>Settings</span>
            </span>
          </button>

          {/* Help */}
          <button
            type="button"
            onClick={() => handleNavigation("/help")}
            className={mainMenuClass(isActive("/help"))}
          >
            <span className="flex items-center gap-3">
              <span aria-hidden="true" className="text-base">
                ⓘ
              </span>
              <span>Help</span>
            </span>
          </button>

          {/* Logout */}
          <button
            type="button"
            onClick={handleLogout}
            className="mb-1 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[13px] font-medium text-[#85918b] transition-all duration-200 hover:bg-[#198754] hover:text-white"
          >
            <span aria-hidden="true" className="text-base">
              ⇥
            </span>
            <span>Logout</span>
          </button>
        </nav>

        {/* Bottom download card */}
        <div className="relative mt-3 shrink-0 overflow-hidden rounded-2xl bg-[#071c13] p-3.5 text-white">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -right-8 top-8 h-24 w-24 rounded-full border border-[#176b43] opacity-70"
          />

          <div
            aria-hidden="true"
            className="pointer-events-none absolute -right-2 top-14 h-20 w-20 rounded-full border border-[#176b43] opacity-60"
          />

          <div className="relative">
            <div className="mb-3 flex h-6 w-6 items-center justify-center rounded-full bg-[#e5f4eb] text-xs text-[#18794e]">
              ✦
            </div>

            <h2 className="text-sm font-medium leading-[18px]">
              Student
              <br />
              Mobile App
            </h2>

            <p className="mt-1 text-[9px] text-[#b9c9bf]">
              Manage your institute anywhere
            </p>

            <button
              type="button"
              onClick={() =>
                window.alert(
                  "Please configure your mobile app download link."
                )
              }
              className="mt-4 w-full rounded-full bg-[#167247] px-3 py-2 text-[10px] font-medium text-white transition hover:bg-[#208c58]"
            >
              Download
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
