
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import AdminLayout from "../components/AdminLayout";
import api from "../services/api";

// ==========================================
// LOCAL DATE
// ==========================================

const getToday = () => {
  const now = new Date();

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
};

// ==========================================
// STAFF INFORMATION HELPERS
// ==========================================

const getStaffName = (item) =>
  item?.staffName ||
  item?.staff_name ||
  item?.staff?.staffName ||
  item?.staff?.staff_name ||
  item?.Staff?.staffName ||
  item?.Staff?.staff_name ||
  item?.name ||
  "Unknown Staff";

const getFatherName = (item) =>
  item?.fatherName ||
  item?.father_name ||
  item?.staff?.fatherName ||
  item?.staff?.father_name ||
  item?.Staff?.fatherName ||
  item?.Staff?.father_name ||
  "";

const getTime = (value) => {
  if (!value) return "--";
  return String(value).slice(0, 5);
};

// ==========================================
// WORKING HOURS
// ==========================================

const getHours = (checkIn, checkOut) => {
  if (!checkIn || !checkOut) return "--";

  const [inHour, inMinute] = String(checkIn)
    .slice(0, 5)
    .split(":")
    .map(Number);

  const [outHour, outMinute] = String(checkOut)
    .slice(0, 5)
    .split(":")
    .map(Number);

  let minutes =
    outHour * 60 +
    outMinute -
    (inHour * 60 + inMinute);

  if (minutes < 0) minutes += 24 * 60;

  return `${Math.floor(minutes / 60)}h ${minutes % 60}m`;
};

// ==========================================
// DATE FORMAT
// ==========================================

const formatDate = (date) => {
  if (!date) return "--";

  const dateString = String(date).slice(0, 10);
  const parsedDate = new Date(`${dateString}T00:00:00`);

  if (Number.isNaN(parsedDate.getTime())) {
    return dateString;
  }

  return parsedDate.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

// ==========================================
// STATUS STYLING
// ==========================================

const statusClass = (status) => {
  const classes = {
    Present: "bg-emerald-50 text-emerald-700 border-emerald-100",
    Absent: "bg-red-50 text-red-700 border-red-100",
    Late: "bg-amber-50 text-amber-700 border-amber-100",
    "Half Day": "bg-purple-50 text-purple-700 border-purple-100",
    Leave: "bg-blue-50 text-blue-700 border-blue-100",
  };

  return classes[status] || "bg-gray-100 text-gray-600 border-gray-200";
};

// ==========================================
// STAT CARD
// ==========================================

const StatCard = ({ label, value, icon, dark = false, subtitle }) => {
  return (
    <div
      className={`group rounded-2xl border p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg ${
        dark
          ? "border-transparent bg-gradient-to-br from-[#104e36] to-[#26845e] text-white shadow-md"
          : "border-gray-100 bg-white text-gray-900 shadow-sm"
      }`}
    >
      <div className="flex items-center justify-between">
        <p
          className={`text-sm font-medium ${
            dark ? "text-white/80" : "text-gray-500"
          }`}
        >
          {label}
        </p>

        <div
          className={`flex h-11 w-11 items-center justify-center rounded-full text-xl ${
            dark
              ? "bg-white/15"
              : "bg-emerald-50 text-emerald-800"
          }`}
        >
          {icon}
        </div>
      </div>

      <h2
        className={`mt-4 text-4xl font-bold tracking-tight ${
          dark ? "text-white" : "text-gray-900"
        }`}
      >
        {value}
      </h2>

      <p
        className={`mt-2 text-xs ${
          dark ? "text-white/70" : "text-gray-400"
        }`}
      >
        {subtitle}
      </p>
    </div>
  );
};

// ==========================================
// VIEW STAFF ATTENDANCE
// ==========================================

const ViewStaffAttendance = () => {
  const navigate = useNavigate();

  const [attendanceList, setAttendanceList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [search, setSearch] = useState("");
  const [filterDate, setFilterDate] = useState("");
  const [filterStatus, setFilterStatus] = useState("All");

  const today = getToday();

  // ==========================================
  // LOAD ATTENDANCE RECORDS
  // ==========================================

  const loadAttendance = async () => {
    setLoading(true);
    setError("");

    try {
      const response = await api.get("/staff-attendance");

      const data =
        response.data?.attendance ||
        response.data?.records ||
        response.data?.data ||
        (Array.isArray(response.data) ? response.data : []);

      setAttendanceList(data);
    } catch (err) {
      console.error("Load Staff Attendance Error:", err);

      setError(
        err.response?.data?.message ||
          "Attendance load nahi hui. Backend API routes check karein."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAttendance();
  }, []);

  // ==========================================
  // FILTER ATTENDANCE
  // ==========================================

  const filteredAttendance = useMemo(() => {
    return attendanceList.filter((item) => {
      const staffName = getStaffName(item).toLowerCase();
      const fatherName = getFatherName(item).toLowerCase();

      const status =
        item.status ||
        item.attendanceStatus ||
        item.attendance_status ||
        "";

      const date = String(
        item.date ||
          item.attendanceDate ||
          item.attendance_date ||
          ""
      ).slice(0, 10);

      const query = search.toLowerCase().trim();

      const matchesSearch =
        staffName.includes(query) ||
        fatherName.includes(query);

      const matchesDate =
        !filterDate || date === filterDate;

      const matchesStatus =
        filterStatus === "All" || status === filterStatus;

      return matchesSearch && matchesDate && matchesStatus;
    });
  }, [attendanceList, search, filterDate, filterStatus]);

  // ==========================================
  // TODAY'S STATISTICS
  // ==========================================

  const stats = useMemo(() => {
    const todayRecords = attendanceList.filter(
      (item) =>
        String(
          item.date ||
            item.attendanceDate ||
            item.attendance_date ||
            ""
        ).slice(0, 10) === today
    );

    const getStatus = (item) =>
      item.status ||
      item.attendanceStatus ||
      item.attendance_status;

    return {
      total: todayRecords.length,

      present: todayRecords.filter(
        (item) => getStatus(item) === "Present"
      ).length,

      absent: todayRecords.filter(
        (item) => getStatus(item) === "Absent"
      ).length,

      late: todayRecords.filter(
        (item) => getStatus(item) === "Late"
      ).length,
    };
  }, [attendanceList, today]);

  // ==========================================
  // RESET FILTERS
  // ==========================================

  const resetFilters = () => {
    setSearch("");
    setFilterDate("");
    setFilterStatus("All");
  };

  // ==========================================
  // UI
  // ==========================================

  return (
    <AdminLayout title="Staff Attendance">

      <div className="min-h-screen space-y-6 bg-[#f7f8f6] p-1">

        {/* ================================= */}
        {/* PAGE HEADER */}
        {/* ================================= */}

        <div className="flex flex-col justify-between gap-4 rounded-2xl bg-white p-5 shadow-sm md:flex-row md:items-center md:p-6">

          <div>
            <div className="mb-2 flex items-center gap-2 text-sm text-gray-400">
              <span>Dashboard</span>
              <span>/</span>
              <span>Staff Management</span>
              <span>/</span>
              <span className="font-medium text-emerald-700">
                Attendance
              </span>
            </div>

            <h1 className="text-2xl font-bold tracking-tight text-gray-900 md:text-3xl">
              Staff Attendance
            </h1>

            <p className="mt-2 text-sm text-gray-400">
              Monitor staff check-in, check-out and daily attendance records.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">

            <button
              type="button"
              onClick={loadAttendance}
              disabled={loading}
              className="rounded-full border border-gray-200 bg-white px-5 py-3 text-sm font-semibold text-gray-700 transition hover:border-emerald-700 hover:bg-emerald-50 disabled:opacity-50"
            >
              ↻ Refresh
            </button>

            <button
              type="button"
              onClick={() => navigate("/staff-attendance/add")}
              className="rounded-full bg-gradient-to-r from-[#104e36] to-[#23845d] px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:shadow-lg"
            >
              + Add Attendance
            </button>

          </div>
        </div>

        {/* ================================= */}
        {/* STATISTICS */}
        {/* ================================= */}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">

          <StatCard
            label="Today's Records"
            value={stats.total}
            icon="▤"
            dark={true}
            subtitle="Total attendance entries today"
          />

          <StatCard
            label="Present Staff"
            value={stats.present}
            icon="✓"
            subtitle="Staff marked present today"
          />

          <StatCard
            label="Absent Staff"
            value={stats.absent}
            icon="×"
            subtitle="Staff marked absent today"
          />

          <StatCard
            label="Late Arrivals"
            value={stats.late}
            icon="◷"
            subtitle="Staff arriving late today"
          />

        </div>

        {/* ================================= */}
        {/* ERROR MESSAGE */}
        {/* ================================= */}

        {error && (
          <div className="flex items-center gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            <span className="text-lg">⚠</span>
            {error}
          </div>
        )}

        {/* ================================= */}
        {/* ATTENDANCE TABLE CARD */}
        {/* ================================= */}

        <div className="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">

          {/* TABLE HEADER */}

          <div className="border-b border-gray-100 p-5 md:p-6">

            <div className="flex flex-col justify-between gap-3 md:flex-row md:items-center">

              <div>
                <h2 className="text-lg font-bold text-gray-900">
                  Attendance Records
                </h2>

                <p className="mt-1 text-sm text-gray-400">
                  Search, filter and view all staff attendance.
                </p>
              </div>

              <div className="rounded-full bg-emerald-50 px-4 py-2 text-xs font-semibold text-emerald-800">
                {filteredAttendance.length} Records Found
              </div>

            </div>

            {/* ================================= */}
            {/* SEARCH AND FILTER */}
            {/* ================================= */}

            <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-4">

              {/* SEARCH */}

              <div className="lg:col-span-2">

                <label className="mb-2 block text-xs font-semibold text-gray-500">
                  Search Staff
                </label>

                <div className="relative">

                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg text-gray-400">
                    ⌕
                  </span>

                  <input
                    type="search"
                    value={search}
                    onChange={(event) => setSearch(event.target.value)}
                    placeholder="Search staff or father name..."
                    className="w-full rounded-xl border border-gray-200 bg-[#fafbf9] py-3 pl-11 pr-4 text-sm outline-none transition focus:border-emerald-600 focus:bg-white focus:ring-4 focus:ring-emerald-50"
                  />

                </div>
              </div>

              {/* DATE FILTER */}

              <div>

                <label className="mb-2 block text-xs font-semibold text-gray-500">
                  Filter By Date
                </label>

                <input
                  type="date"
                  value={filterDate}
                  onChange={(event) => setFilterDate(event.target.value)}
                  className="w-full rounded-xl border border-gray-200 bg-[#fafbf9] px-4 py-3 text-sm outline-none transition focus:border-emerald-600 focus:ring-4 focus:ring-emerald-50"
                />

              </div>

              {/* STATUS FILTER */}

              <div>

                <label className="mb-2 block text-xs font-semibold text-gray-500">
                  Filter By Status
                </label>

                <select
                  value={filterStatus}
                  onChange={(event) => setFilterStatus(event.target.value)}
                  className="w-full rounded-xl border border-gray-200 bg-[#fafbf9] px-4 py-3 text-sm outline-none transition focus:border-emerald-600 focus:ring-4 focus:ring-emerald-50"
                >
                  <option value="All">All Statuses</option>
                  <option value="Present">Present</option>
                  <option value="Absent">Absent</option>
                  <option value="Late">Late</option>
                  <option value="Half Day">Half Day</option>
                  <option value="Leave">Leave</option>
                </select>

              </div>

            </div>

            {/* RESET FILTER */}

            <div className="mt-4 flex justify-end">

              <button
                type="button"
                onClick={resetFilters}
                className="text-xs font-semibold text-emerald-800 transition hover:text-emerald-950"
              >
                ↻ Clear All Filters
              </button>

            </div>

          </div>

          {/* ================================= */}
          {/* ATTENDANCE TABLE */}
          {/* ================================= */}

          <div className="overflow-x-auto">

            <table className="w-full min-w-[1050px] text-left text-sm">

              <thead className="bg-[#f8faf8] text-xs uppercase tracking-wider text-gray-500">

                <tr>
                  <th className="px-5 py-4 font-semibold">#</th>
                  <th className="px-5 py-4 font-semibold">Staff Member</th>
                  <th className="px-5 py-4 font-semibold">Date</th>
                  <th className="px-5 py-4 font-semibold">Check-in</th>
                  <th className="px-5 py-4 font-semibold">Check-out</th>
                  <th className="px-5 py-4 font-semibold">Working Hours</th>
                  <th className="px-5 py-4 font-semibold">Status</th>
                  <th className="px-5 py-4 font-semibold">Remarks</th>
                </tr>

              </thead>

              <tbody className="divide-y divide-gray-100">

                {/* LOADING */}

                {loading ? (

                  <tr>
                    <td colSpan={8} className="px-5 py-16 text-center">

                      <div className="flex flex-col items-center gap-3">

                        <div className="h-9 w-9 animate-spin rounded-full border-4 border-emerald-100 border-t-emerald-700" />

                        <p className="text-sm text-gray-500">
                          Loading attendance records...
                        </p>

                      </div>

                    </td>
                  </tr>

                ) : filteredAttendance.length === 0 ? (

                  /* EMPTY STATE */

                  <tr>
                    <td colSpan={8} className="px-5 py-16 text-center">

                      <div className="flex flex-col items-center gap-3">

                        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50 text-3xl text-emerald-800">
                          ▤
                        </div>

                        <h3 className="font-bold text-gray-800">
                          No Attendance Records Found
                        </h3>

                        <p className="max-w-sm text-sm text-gray-400">
                          No records match your search or selected filters.
                        </p>

                        <button
                          type="button"
                          onClick={resetFilters}
                          className="mt-2 text-sm font-semibold text-emerald-800 hover:underline"
                        >
                          Clear Filters
                        </button>

                      </div>

                    </td>
                  </tr>

                ) : (

                  /* ATTENDANCE DATA */

                  filteredAttendance.map((item, index) => {

                    const checkIn =
                      item.checkIn ||
                      item.checkInTime ||
                      item.check_in;

                    const checkOut =
                      item.checkOut ||
                      item.checkOutTime ||
                      item.check_out;

                    const status =
                      item.status ||
                      item.attendanceStatus ||
                      item.attendance_status;

                    const date =
                      item.date ||
                      item.attendanceDate ||
                      item.attendance_date;

                    return (

                      <tr
                        key={item.id || index}
                        className="transition-colors hover:bg-[#f7faf7]"
                      >

                        {/* NUMBER */}

                        <td className="px-5 py-5 text-gray-400">
                          {index + 1}
                        </td>

                        {/* STAFF */}

                        <td className="px-5 py-5">

                          <div className="flex items-center gap-3">

                            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-100 font-bold text-emerald-800">
                              {getStaffName(item).charAt(0).toUpperCase()}
                            </div>

                            <div>
                              <p className="font-semibold text-gray-800">
                                {getStaffName(item)}
                              </p>

                              <p className="mt-1 text-xs text-gray-400">
                                {getFatherName(item) || "Staff Member"}
                              </p>
                            </div>

                          </div>

                        </td>

                        {/* DATE */}

                        <td className="px-5 py-5 whitespace-nowrap text-gray-600">
                          {formatDate(date)}
                        </td>

                        {/* CHECK IN */}

                        <td className="px-5 py-5 whitespace-nowrap">

                          <span className="font-semibold text-emerald-700">
                            {getTime(checkIn)}
                          </span>

                        </td>

                        {/* CHECK OUT */}

                        <td className="px-5 py-5 whitespace-nowrap">

                          <span className="font-semibold text-red-600">
                            {getTime(checkOut)}
                          </span>

                        </td>

                        {/* WORKING HOURS */}

                        <td className="px-5 py-5 whitespace-nowrap">

                          <span className="rounded-lg bg-gray-100 px-3 py-2 text-xs font-semibold text-gray-700">
                            {getHours(checkIn, checkOut)}
                          </span>

                        </td>

                        {/* STATUS */}

                        <td className="px-5 py-5 whitespace-nowrap">

                          <span
                            className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold ${statusClass(status)}`}
                          >
                            <span className="h-1.5 w-1.5 rounded-full bg-current" />
                            {status || "Not Set"}
                          </span>

                        </td>

                        {/* REMARKS */}

                        <td className="max-w-[180px] px-5 py-5 text-gray-500">
                          <span className="block truncate" title={item.remarks || ""}>
                            {item.remarks || "--"}
                          </span>
                        </td>

                      </tr>

                    );
                  })

                )}

              </tbody>

            </table>

          </div>

          {/* ================================= */}
          {/* TABLE FOOTER */}
          {/* ================================= */}

          <div className="flex flex-col justify-between gap-2 border-t border-gray-100 bg-[#fafbf9] px-5 py-4 sm:flex-row sm:items-center">

            <p className="text-xs text-gray-500">
              Showing{" "}
              <strong className="text-gray-800">
                {filteredAttendance.length}
              </strong>{" "}
              of{" "}
              <strong className="text-gray-800">
                {attendanceList.length}
              </strong>{" "}
              attendance records
            </p>

            <p className="text-xs font-medium text-emerald-800">
              Staff Attendance Management
            </p>

          </div>

        </div>

        {/* ================================= */}
        {/* BOTTOM INFORMATION */}
        {/* ================================= */}

        <div className="rounded-xl border border-emerald-100 bg-emerald-50/60 p-4">

          <p className="text-xs leading-6 text-emerald-900">
            <strong>Note:</strong> Today's statistics display records
            for the current date. Use search, date and status filters
            to find specific staff attendance records.
          </p>

        </div>

      </div>

    </AdminLayout>
  );
};

export default ViewStaffAttendance;
