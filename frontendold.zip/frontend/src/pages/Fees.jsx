import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

import AdminLayout from "../components/AdminLayout";
import api from "../services/api";

// ==========================================
// CURRENT MONTH
// ==========================================

const getCurrentMonth = () => {
  const now = new Date();

  return (
    now.getFullYear() +
    "-" +
    String(now.getMonth() + 1).padStart(2, "0")
  );
};

// ==========================================
// CURRENCY FORMAT
// ==========================================

const formatCurrency = (amount) =>
  "Rs " +
  Number(amount || 0).toLocaleString("en-PK", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });

// ==========================================
// MONTH FORMAT
// ==========================================

const formatMonth = (month) => {
  if (!month) return "--";

  const [year, monthNumber] = month.split("-").map(Number);

  const date = new Date(year, monthNumber - 1, 1);

  return date.toLocaleDateString("en-PK", {
    month: "short",
    year: "numeric",
  });
};

// ==========================================
// TOTAL PAYMENTS BY MONTH
// ==========================================

const getMonthlyPayments = (payments = []) => {
  const monthlyTotals = {};

  payments.forEach((payment) => {
    const month = payment.month;

    monthlyTotals[month] =
      (monthlyTotals[month] || 0) +
      Number(payment.amountPaid || 0);
  });

  return Object.entries(monthlyTotals).sort(([monthA], [monthB]) =>
    monthA.localeCompare(monthB)
  );
};

// ==========================================
// FEES COMPONENT
// ==========================================

const Fees = () => {
  const navigate = useNavigate();

  const [feeAccounts, setFeeAccounts] = useState([]);
  const [courses, setCourses] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const [clearingId, setClearingId] = useState(null);

  // ==========================================
  // LOAD FEES AND COURSES
  // ==========================================

  const loadData = async () => {
    try {
      setLoading(true);
      setError("");

      const [feeResponse, courseResponse] = await Promise.all([
        api.get("/fees"),
        api.get("/courses"),
      ]);

      setFeeAccounts(feeResponse.data?.fees || []);

      setCourses(courseResponse.data?.courses || []);
    } catch (err) {
      console.error("Load Fees Error:", err);

      setError(
        err.response?.data?.message ||
          "Failed to load fee records."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // ==========================================
  // GET COURSE DURATION
  // ==========================================

  const getCourseDuration = (student) => {
    const courseName = student?.course || "";

    const course = courses.find(
      (item) =>
        item.courseName?.trim().toLowerCase() ===
        courseName.trim().toLowerCase()
    );

    return course?.courseDuration || "--";
  };

  // ==========================================
  // CALCULATE ACCOUNT TOTALS
  // ==========================================

  const getAccountTotals = (fee) => {
    const totalFee = Number(fee.totalFee || 0);

    const payments = fee.payments || [];

    const paid = payments.reduce(
      (sum, payment) =>
        sum + Number(payment.amountPaid || 0),
      0
    );

    const balance = Math.max(0, totalFee - paid);

    return {
      totalFee,
      paid,
      balance,
      status:
        balance <= 0.005
          ? "Cleared"
          : "Pending",
    };
  };

  // ==========================================
  // FILTER FEES
  // ==========================================

  const filteredFees = useMemo(() => {
    return feeAccounts.filter((fee) => {
      const student = fee.student || {};

      const totals = getAccountTotals(fee);

      const query = search.trim().toLowerCase();

      const matchesSearch = [
        student.name,
        student.fatherName,
        student.course,
      ].some((value) =>
        String(value || "")
          .toLowerCase()
          .includes(query)
      );

      const matchesStatus =
        statusFilter === "All" ||
        totals.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [feeAccounts, search, statusFilter]);

  // ==========================================
  // STATISTICS
  // ==========================================

  const statistics = useMemo(() => {
    const totalAccounts = feeAccounts.length;

    const totalFeeAmount = feeAccounts.reduce(
      (sum, fee) =>
        sum + getAccountTotals(fee).totalFee,
      0
    );

    const totalCollected = feeAccounts.reduce(
      (sum, fee) =>
        sum + getAccountTotals(fee).paid,
      0
    );

    const totalOutstanding = feeAccounts.reduce(
      (sum, fee) =>
        sum + getAccountTotals(fee).balance,
      0
    );

    const clearedAccounts = feeAccounts.filter(
      (fee) => getAccountTotals(fee).status === "Cleared"
    ).length;

    return {
      totalAccounts,
      totalFeeAmount,
      totalCollected,
      totalOutstanding,
      clearedAccounts,
    };
  }, [feeAccounts]);

  // ==========================================
  // COLLECTION PERCENTAGE
  // ==========================================

  const collectionPercentage =
    statistics.totalFeeAmount > 0
      ? Math.min(
          100,
          Math.round(
            (statistics.totalCollected /
              statistics.totalFeeAmount) *
              100
          )
        )
      : 0;

  // ==========================================
  // CLEAR REMAINING FEES
  // ==========================================

  const handleClearFees = async (fee) => {
    const totals = getAccountTotals(fee);

    if (totals.balance <= 0) return;

    const studentName =
      fee.student?.name || "this student";

    const confirmed = window.confirm(
      `Clear the remaining fee for ${studentName}?\n\nRemaining balance: ${formatCurrency(
        totals.balance
      )}`
    );

    if (!confirmed) return;

    try {
      setClearingId(fee.id);
      setError("");
      setMessage("");

      const response = await api.post(
        `/fees/${fee.id}/clear`,
        {
          month: getCurrentMonth(),
        }
      );

      if (response.data?.success) {
        setMessage(
          response.data.message ||
            "Fees cleared successfully."
        );

        await loadData();
      } else {
        setError(
          response.data?.message ||
            "Unable to clear fees."
        );
      }
    } catch (err) {
      console.error("Clear Fees Error:", err);

      setError(
        err.response?.data?.message ||
          "Failed to clear remaining fees."
      );
    } finally {
      setClearingId(null);
    }
  };

  // ==========================================
  // UI
  // ==========================================

  return (
    <AdminLayout title="Fees Management">
      <div className="min-h-screen space-y-5 bg-[#f6f7f6] p-2 sm:p-3">

        {/* ====================================== */}
        {/* PAGE HEADER */}
        {/* ====================================== */}

        <div className="flex flex-col justify-between gap-5 rounded-[24px] bg-white p-5 shadow-sm lg:flex-row lg:items-center">

          <div>
            <p className="mb-1 text-sm font-medium text-[#168257]">
              Finance Overview
            </p>

            <h1 className="text-3xl font-bold tracking-tight text-[#111827]">
              Fees Management
            </h1>

            <p className="mt-2 text-sm text-gray-400">
              Manage student fees, payments and outstanding balances.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">

            <button
              type="button"
              onClick={() => navigate("/fees/add")}
              className="flex items-center gap-2 rounded-full bg-gradient-to-r from-[#0b563c] to-[#17865b] px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-green-900/10 transition hover:-translate-y-0.5 hover:shadow-xl"
            >
              <span className="text-lg leading-none">+</span>
              Add Fee
            </button>

            <button
              type="button"
              onClick={loadData}
              className="rounded-full border border-[#1b6b4d] bg-white px-6 py-3 text-sm font-semibold text-[#155d43] transition hover:bg-[#edf7f1]"
            >
              ↻ Refresh
            </button>

          </div>
        </div>

        {/* ====================================== */}
        {/* ALERTS */}
        {/* ====================================== */}

        {error && (
          <div className="rounded-2xl border border-red-200 bg-red-50 px-5 py-4 text-sm font-medium text-red-700">
            {error}
          </div>
        )}

        {message && (
          <div className="rounded-2xl border border-green-200 bg-green-50 px-5 py-4 text-sm font-medium text-green-700">
            ✓ {message}
          </div>
        )}

        {/* ====================================== */}
        {/* STATISTICS */}
        {/* ====================================== */}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">

          {/* TOTAL ACCOUNTS */}

          <div className="rounded-[22px] bg-gradient-to-br from-[#084c35] via-[#116f4d] to-[#1d925f] p-5 text-white shadow-lg">

            <div className="flex items-start justify-between">

              <div>
                <p className="text-sm font-medium text-green-50/80">
                  Fee Accounts
                </p>

                <p className="mt-5 text-4xl font-bold">
                  {statistics.totalAccounts}
                </p>
              </div>

              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/90 text-lg text-[#155d43]">
                ↗
              </div>

            </div>

            <div className="mt-6 flex items-center gap-2 text-xs text-green-100">
              <span className="rounded-md border border-green-300/40 px-1.5 py-0.5">
                📋
              </span>
              Total registered accounts
            </div>

          </div>

          {/* TOTAL FEES */}

          <div className="rounded-[22px] bg-white p-5 shadow-sm">

            <div className="flex items-start justify-between">

              <div>
                <p className="text-sm font-medium text-gray-500">
                  Total Fees
                </p>

                <p className="mt-5 text-2xl font-bold text-gray-900">
                  {formatCurrency(
                    statistics.totalFeeAmount
                  )}
                </p>
              </div>

              <div className="flex h-10 w-10 items-center justify-center rounded-full border border-gray-800 text-lg">
                ₨
              </div>

            </div>

            <p className="mt-6 text-xs text-[#438d67]">
              Total fee amount
            </p>

          </div>

          {/* COLLECTED */}

          <div className="rounded-[22px] bg-white p-5 shadow-sm">

            <div className="flex items-start justify-between">

              <div>
                <p className="text-sm font-medium text-gray-500">
                  Total Collected
                </p>

                <p className="mt-5 text-2xl font-bold text-[#168257]">
                  {formatCurrency(
                    statistics.totalCollected
                  )}
                </p>
              </div>

              <div className="flex h-10 w-10 items-center justify-center rounded-full border border-[#168257] text-lg text-[#168257]">
                ✓
              </div>

            </div>

            <p className="mt-6 text-xs text-[#438d67]">
              {collectionPercentage}% collection completed
            </p>

          </div>

          {/* OUTSTANDING */}

          <div className="rounded-[22px] bg-white p-5 shadow-sm">

            <div className="flex items-start justify-between">

              <div>
                <p className="text-sm font-medium text-gray-500">
                  Outstanding Balance
                </p>

                <p className="mt-5 text-2xl font-bold text-red-600">
                  {formatCurrency(
                    statistics.totalOutstanding
                  )}
                </p>
              </div>

              <div className="flex h-10 w-10 items-center justify-center rounded-full border border-red-300 text-lg text-red-600">
                !
              </div>

            </div>

            <p className="mt-6 text-xs text-red-400">
              Pending student payments
            </p>

          </div>

        </div>

        {/* ====================================== */}
        {/* ANALYTICS ROW */}
        {/* ====================================== */}

        <div className="grid grid-cols-1 gap-5 xl:grid-cols-3">

          {/* COLLECTION PROGRESS */}

          <div className="rounded-[22px] bg-white p-6 shadow-sm xl:col-span-2">

            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">

              <div>
                <h2 className="text-lg font-bold text-gray-900">
                  Fee Collection Progress
                </h2>

                <p className="mt-1 text-sm text-gray-400">
                  Overall collection performance
                </p>
              </div>

              <div className="rounded-full bg-[#edf7f1] px-4 py-2 text-sm font-bold text-[#168257]">
                {collectionPercentage}% Collected
              </div>

            </div>

            <div className="mt-8">

              <div className="mb-3 flex justify-between text-sm">

                <span className="font-medium text-gray-500">
                  Collection Progress
                </span>

                <span className="font-bold text-gray-800">
                  {formatCurrency(
                    statistics.totalCollected
                  )}
                  {" / "}
                  {formatCurrency(
                    statistics.totalFeeAmount
                  )}
                </span>

              </div>

              <div className="h-4 overflow-hidden rounded-full bg-[#e8efeb]">

                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#0b563c] to-[#35a875] transition-all duration-500"
                  style={{
                    width: `${collectionPercentage}%`,
                  }}
                />

              </div>

            </div>

            <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">

              <div className="rounded-2xl bg-[#f7faf8] p-4">
                <p className="text-xs text-gray-400">
                  Total Accounts
                </p>

                <p className="mt-2 text-xl font-bold text-gray-800">
                  {statistics.totalAccounts}
                </p>
              </div>

              <div className="rounded-2xl bg-[#eff9f3] p-4">
                <p className="text-xs text-gray-400">
                  Cleared Accounts
                </p>

                <p className="mt-2 text-xl font-bold text-[#168257]">
                  {statistics.clearedAccounts}
                </p>
              </div>

              <div className="rounded-2xl bg-[#fff7f5] p-4">
                <p className="text-xs text-gray-400">
                  Pending Accounts
                </p>

                <p className="mt-2 text-xl font-bold text-red-500">
                  {statistics.totalAccounts -
                    statistics.clearedAccounts}
                </p>
              </div>

            </div>

          </div>

          {/* QUICK ACTION */}

          <div className="rounded-[22px] bg-gradient-to-br from-[#073e2c] to-[#126a49] p-6 text-white shadow-lg">

            <p className="text-sm text-green-100">
              Quick Action
            </p>

            <h2 className="mt-2 text-2xl font-bold">
              Add New Payment
            </h2>

            <p className="mt-3 text-sm leading-6 text-green-100/80">
              Record a new student fee payment and
              automatically update the remaining balance.
            </p>

            <button
              type="button"
              onClick={() => navigate("/fees/add")}
              className="mt-8 w-full rounded-xl bg-white px-4 py-3 font-semibold text-[#0d5b3e] transition hover:bg-green-50"
            >
              + Add Fee Payment
            </button>

          </div>

        </div>

        {/* ====================================== */}
        {/* SEARCH & FILTER */}
        {/* ====================================== */}

        <div className="rounded-[22px] bg-white p-5 shadow-sm">

          <div className="mb-5">

            <h2 className="text-lg font-bold text-gray-900">
              Search & Filter
            </h2>

            <p className="mt-1 text-sm text-gray-400">
              Find student fee accounts quickly.
            </p>

          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">

            <div>
              <label className="mb-2 block text-sm font-semibold text-gray-700">
                Search Student
              </label>

              <div className="relative">

                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                  🔍
                </span>

                <input
                  type="search"
                  value={search}
                  onChange={(event) =>
                    setSearch(event.target.value)
                  }
                  placeholder="Name, father name or course..."
                  className="w-full rounded-xl border border-gray-200 bg-[#fafcfb] py-3 pl-11 pr-4 text-sm outline-none transition focus:border-[#168257] focus:ring-4 focus:ring-green-100"
                />

              </div>
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold text-gray-700">
                Fee Status
              </label>

              <select
                value={statusFilter}
                onChange={(event) =>
                  setStatusFilter(event.target.value)
                }
                className="w-full rounded-xl border border-gray-200 bg-[#fafcfb] px-4 py-3 text-sm outline-none transition focus:border-[#168257] focus:ring-4 focus:ring-green-100"
              >
                <option value="All">
                  All Accounts
                </option>

                <option value="Pending">
                  Pending Fees
                </option>

                <option value="Cleared">
                  Cleared Fees
                </option>
              </select>
            </div>

          </div>

        </div>

        {/* ====================================== */}
        {/* FEE RECORDS */}
        {/* ====================================== */}

        <div className="overflow-hidden rounded-[22px] bg-white shadow-sm">

          <div className="flex flex-col justify-between gap-4 border-b border-gray-100 p-6 sm:flex-row sm:items-center">

            <div>
              <h2 className="text-lg font-bold text-gray-900">
                Student Fee Records
              </h2>

              <p className="mt-1 text-sm text-gray-400">
                Showing {filteredFees.length} of{" "}
                {feeAccounts.length} accounts
              </p>
            </div>

            <button
              type="button"
              onClick={loadData}
              className="rounded-full border border-gray-200 px-4 py-2 text-sm font-semibold text-gray-600 transition hover:bg-gray-50"
            >
              ↻ Refresh Records
            </button>

          </div>

          <div className="overflow-x-auto">

            <table className="w-full min-w-[1350px] text-left text-sm">

              <thead className="border-b border-gray-100 bg-[#f8faf9] text-xs uppercase tracking-wide text-gray-400">

                <tr>
                  <th className="px-5 py-4">#</th>
                  <th className="px-5 py-4">Student</th>
                  <th className="px-5 py-4">Course</th>
                  <th className="px-5 py-4">Duration</th>
                  <th className="px-5 py-4">Total Fee</th>
                  <th className="px-5 py-4">Paid</th>
                  <th className="px-5 py-4">Balance</th>
                  <th className="px-5 py-4">Monthly Payments</th>
                  <th className="px-5 py-4">Status</th>
                  <th className="px-5 py-4">Actions</th>
                </tr>

              </thead>

              <tbody className="divide-y divide-gray-100">

                {loading ? (

                  <tr>
                    <td
                      colSpan={10}
                      className="px-5 py-14 text-center text-gray-400"
                    >
                      Loading fee records...
                    </td>
                  </tr>

                ) : filteredFees.length === 0 ? (

                  <tr>
                    <td
                      colSpan={10}
                      className="px-5 py-14 text-center text-gray-400"
                    >
                      No fee records found.
                    </td>
                  </tr>

                ) : (

                  filteredFees.map((fee, index) => {
                    const student = fee.student || {};

                    const totals =
                      getAccountTotals(fee);

                    const monthlyPayments =
                      getMonthlyPayments(
                        fee.payments || []
                      );

                    return (

                      <tr
                        key={fee.id}
                        className="align-top transition hover:bg-[#f8fbf9]"
                      >

                        <td className="px-5 py-5 text-gray-400">
                          {String(index + 1).padStart(
                            2,
                            "0"
                          )}
                        </td>

                        {/* STUDENT */}

                        <td className="px-5 py-5">

                          <div className="flex items-center gap-3">

                            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#e8f5ee] font-bold text-[#168257]">
                              {(student.name || "S")
                                .charAt(0)
                                .toUpperCase()}
                            </div>

                            <div>

                              <p className="font-bold text-gray-800">
                                {student.name || "--"}
                              </p>

                              <p className="mt-1 text-xs text-gray-400">
                                Father:{" "}
                                {student.fatherName ||
                                  "--"}
                              </p>

                            </div>

                          </div>

                        </td>

                        {/* COURSE */}

                        <td className="px-5 py-5">

                          <span className="font-medium text-gray-700">
                            {student.course || "--"}
                          </span>

                        </td>

                        {/* DURATION */}

                        <td className="px-5 py-5 text-gray-500">
                          {getCourseDuration(student)}
                        </td>

                        {/* TOTAL */}

                        <td className="px-5 py-5 font-bold text-gray-800">
                          {formatCurrency(
                            totals.totalFee
                          )}
                        </td>

                        {/* PAID */}

                        <td className="px-5 py-5">

                          <span className="font-bold text-[#168257]">
                            {formatCurrency(
                              totals.paid
                            )}
                          </span>

                        </td>

                        {/* BALANCE */}

                        <td className="px-5 py-5">

                          <span
                            className={
                              totals.balance > 0
                                ? "font-bold text-red-500"
                                : "font-bold text-[#168257]"
                            }
                          >
                            {formatCurrency(
                              totals.balance
                            )}
                          </span>

                        </td>

                        {/* MONTHLY PAYMENTS */}

                        <td className="px-5 py-5">

                          {monthlyPayments.length === 0 ? (

                            <span className="text-gray-400">
                              No payments
                            </span>

                          ) : (

                            <div className="space-y-2">

                              {monthlyPayments.map(
                                ([month, amount]) => (

                                  <div
                                    key={month}
                                    className="flex items-center justify-between gap-3 rounded-lg bg-[#f7faf8] px-3 py-2"
                                  >

                                    <span className="text-xs text-gray-500">
                                      {formatMonth(month)}
                                    </span>

                                    <span className="text-xs font-bold text-gray-800">
                                      {formatCurrency(
                                        amount
                                      )}
                                    </span>

                                  </div>
                                )
                              )}

                            </div>

                          )}

                        </td>

                        {/* STATUS */}

                        <td className="px-5 py-5">

                          <span
                            className={`rounded-full px-3 py-1.5 text-xs font-bold ${
                              totals.status ===
                              "Cleared"
                                ? "bg-[#e7f7ed] text-[#168257]"
                                : "bg-[#fff4db] text-[#b7791f]"
                            }`}
                          >
                            {totals.status ===
                            "Cleared"
                              ? "✓ Cleared"
                              : "● Pending"}
                          </span>

                        </td>

                        {/* ACTIONS */}

                        <td className="px-5 py-5">

                          <div className="flex flex-col items-start gap-2">

                            {totals.balance > 0.005 && (
                              <>

                                <button
                                  type="button"
                                  onClick={() =>
                                    navigate(
                                      `/fees/add?studentId=${student.id}`
                                    )
                                  }
                                  className="whitespace-nowrap rounded-lg bg-[#edf7f1] px-3 py-2 text-xs font-bold text-[#168257] transition hover:bg-[#d9f0e3]"
                                >
                                  + Add Payment
                                </button>

                                <button
                                  type="button"
                                  onClick={() =>
                                    handleClearFees(fee)
                                  }
                                  disabled={
                                    clearingId ===
                                    fee.id
                                  }
                                  className="whitespace-nowrap rounded-lg bg-gradient-to-r from-[#0b563c] to-[#168257] px-3 py-2 text-xs font-bold text-white transition hover:shadow-md disabled:opacity-50"
                                >
                                  {clearingId === fee.id
                                    ? "Clearing..."
                                    : "✓ Clear Fees"}
                                </button>

                              </>
                            )}

                            {totals.balance <=
                              0.005 && (

                              <span className="rounded-lg bg-[#e7f7ed] px-3 py-2 text-xs font-bold text-[#168257]">
                                ✓ Fully Paid
                              </span>

                            )}

                          </div>

                        </td>

                      </tr>
                    );
                  })

                )}

              </tbody>

            </table>

          </div>

          {/* FOOTER */}

          <div className="flex flex-col justify-between gap-2 border-t border-gray-100 px-6 py-4 text-sm text-gray-400 sm:flex-row">

            <span>
              Showing {filteredFees.length} records
            </span>

            <span>
              Total outstanding:{" "}
              <strong className="text-red-500">
                {formatCurrency(
                  statistics.totalOutstanding
                )}
              </strong>
            </span>

          </div>

        </div>

      </div>
    </AdminLayout>
  );
};

export default Fees;